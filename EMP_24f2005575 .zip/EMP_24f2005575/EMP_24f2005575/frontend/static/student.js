// #24f2005575- Asmita
EMP.views.studentHome = {
  setup() {
    const d = ref(null);
    const load = async () => (d.value = await api("/student/dashboard"));
    onMounted(load);
    const exportCsv = () => act(() => api("/student/export", "POST"), true);
    return { d, exportCsv };
  },
  template: `
  <div v-if="d">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="mb-0">Student Dashboard</h4>
      <button class="btn btn-outline-primary btn-sm" @click="exportCsv">⬇ Export my history (CSV)</button>
    </div>
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3"><div class="card p-3"><div class="stat">{{ d.available_exams }}</div>Exams open for booking</div></div>
      <div class="col-6 col-md-3"><div class="card p-3"><div class="stat">{{ d.available_slots }}</div>Available slots</div></div>
      <div class="col-6 col-md-3"><div class="card p-3"><div class="stat">{{ d.upcoming.length }}</div>Upcoming exams</div></div>
      <div class="col-6 col-md-3"><div class="card p-3"><div class="stat">{{ d.results.length }}</div>Published results</div></div>
    </div>
    <h5>Upcoming examinations</h5>
    <div class="table-responsive mb-4"><table class="table mb-0">
      <thead><tr><th>Exam</th><th>Date</th><th>Time</th><th>Examiner</th><th>Link</th></tr></thead>
      <tbody>
        <tr v-for="b in d.upcoming" :key="b.id"><td>{{ b.exam }}</td><td>{{ b.date }}</td>
          <td>{{ b.start_time }} - {{ b.end_time }}</td><td>{{ b.examiner }}</td>
          <td><a v-if="b.meeting_link" :href="b.meeting_link" target="_blank">Join</a></td></tr>
        <tr v-if="!d.upcoming.length"><td colspan="5" class="text-muted">No upcoming examinations.</td></tr>
      </tbody></table></div>
    <h5>Published results</h5>
    <div class="table-responsive"><table class="table mb-0">
      <thead><tr><th>Exam</th><th>Marks</th><th>Examiner feedback</th></tr></thead>
      <tbody>
        <tr v-for="b in d.results" :key="b.id"><td>{{ b.exam }}</td><td>{{ b.marks }} / {{ b.max_marks }}</td><td>{{ b.remarks }}</td></tr>
        <tr v-if="!d.results.length"><td colspan="3" class="text-muted">No results published yet.</td></tr>
      </tbody></table></div>
  </div>`
};

EMP.views.studentExams = {
  setup() {
    const exams = ref([]), slots = ref([]), selected = ref(null);
    const filter = reactive({ q: "", type: "", status: "" });
    const types = ["Viva", "Practical", "Project Demo", "Assessment"];
    const statuses = ["Slot Creation", "Booking Open", "Closed", "Completed"];

    async function load() {
      const qs = new URLSearchParams(Object.entries(filter).filter(([, v]) => v)).toString();
      exams.value = await api("/student/exams?" + qs);
    }
    async function showSlots(e) {
      selected.value = e;
      slots.value = await api(`/student/exams/${e.id}/slots`);
    }
    async function book(s) {
      if (!confirm(`Book ${s.date} ${s.start_time}-${s.end_time} with ${s.examiner}?`)) return;
      const r = await act(() => api(`/student/slots/${s.id}/book`, "POST"), true);
      if (r) { await load(); await showSlots(selected.value); selected.value.already_booked = true; }
    }
    onMounted(load);
    return { exams, slots, selected, filter, types, statuses, load, showSlots, book, badge };
  },
  template: `
  <h4>Examinations</h4>
  <form class="row g-2 mb-3" @submit.prevent="load">
    <div class="col-md-5"><input class="form-control" v-model="filter.q" placeholder="Search by exam or course"></div>
    <div class="col-6 col-md-3"><select class="form-select" v-model="filter.type"><option value="">All types</option><option v-for="t in types">{{ t }}</option></select></div>
    <div class="col-6 col-md-3"><select class="form-select" v-model="filter.status"><option value="">All statuses</option><option v-for="t in statuses">{{ t }}</option></select></div>
    <div class="col-md-1"><button class="btn btn-primary w-100">Go</button></div>
  </form>
  <div class="table-responsive mb-4"><table class="table table-hover mb-0">
    <thead><tr><th>Exam</th><th>Course</th><th>Type</th><th>Duration</th><th>Marks</th><th>Booking window</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <tr v-for="e in exams" :key="e.id">
        <td>{{ e.name }}</td><td>{{ e.course_code }}</td><td>{{ e.exam_type }}</td><td>{{ e.duration }} min</td><td>{{ e.max_marks }}</td>
        <td>{{ e.booking_start }} → {{ e.booking_end }}</td>
        <td><span class="badge" :class="'bg-'+badge(e.status)">{{ e.status }}</span></td>
        <td><button class="btn btn-sm btn-outline-primary" @click="showSlots(e)">View slots</button></td></tr>
      <tr v-if="!exams.length"><td colspan="8" class="text-muted">No examinations found.</td></tr>
    </tbody></table></div>

  <div v-if="selected" class="card"><div class="card-body">
    <h5>Slots for {{ selected.name }} <span class="badge" :class="'bg-'+badge(selected.status)">{{ selected.status }}</span></h5>
    <p class="small text-muted">{{ selected.instructions }}</p>
    <div v-if="selected.already_booked" class="alert alert-info py-2">You already booked this exam (see "My Bookings").</div>
    <div class="table-responsive"><table class="table mb-0">
      <thead><tr><th>Date</th><th>Time</th><th>Examiner</th><th>Seats left</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <tr v-for="s in slots" :key="s.id"><td>{{ s.date }}</td><td>{{ s.start_time }} - {{ s.end_time }}</td><td>{{ s.examiner }}</td>
          <td>{{ s.available_seats }} / {{ s.capacity }}</td>
          <td><span class="badge" :class="'bg-'+badge(s.status)">{{ s.status }}</span></td>
          <td><button class="btn btn-sm btn-success" :disabled="s.status!=='Available' || selected.status!=='Booking Open' || selected.already_booked" @click="book(s)">Book</button></td></tr>
        <tr v-if="!slots.length"><td colspan="6" class="text-muted">No slots created yet.</td></tr>
      </tbody></table></div>
  </div></div>`
};

EMP.views.studentBookings = {
  setup() {
    const rows = ref([]);
    const load = async () => (rows.value = await api("/student/bookings"));
    const cancel = async (b) => {
      if (!confirm("Cancel this booking?")) return;
      if (await act(() => api(`/student/bookings/${b.id}/cancel`, "POST"), true)) load();
    };
    onMounted(load);
    return { rows, cancel, badge };
  },
  template: `
  <h4>My Bookings &amp; Examination History</h4>
  <div class="table-responsive"><table class="table mb-0">
    <thead><tr><th>Exam</th><th>Course</th><th>Date</th><th>Time</th><th>Examiner</th><th>Status</th><th>Result</th><th></th></tr></thead>
    <tbody>
      <tr v-for="b in rows" :key="b.id"><td>{{ b.exam }}</td><td>{{ b.course }}</td><td>{{ b.date }}</td>
        <td>{{ b.start_time }}-{{ b.end_time }}</td><td>{{ b.examiner }}</td>
        <td><span class="badge" :class="'bg-'+badge(b.status)">{{ b.status }}</span></td>
        <td><span v-if="b.marks!==undefined">{{ b.marks }}/{{ b.max_marks }}<div class="small text-muted">{{ b.remarks }}</div></span>
            <span v-else class="text-muted small">{{ b.evaluated ? 'Not published' : '—' }}</span></td>
        <td><button v-if="b.status==='Booked'" class="btn btn-sm btn-outline-danger" @click="cancel(b)">Cancel</button></td></tr>
      <tr v-if="!rows.length"><td colspan="8" class="text-muted">No bookings yet.</td></tr>
    </tbody></table></div>`
};
