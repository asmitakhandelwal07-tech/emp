// #24f2005575- Asmita
EMP.views.examinerHome = {
  setup() {
    const d = ref(null), exams = ref([]);
    const load = async () => { d.value = await api("/examiner/dashboard"); exams.value = await api("/examiner/exams"); };
    const complete = async (e) => { if (await act(() => api(`/examiner/exams/${e.id}/complete`, "PUT"), "Exam marked completed")) load(); };
    onMounted(load);
    return { d, exams, complete, badge };
  },
  template: `
  <div v-if="d">
    <h4>Examiner Dashboard</h4>
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3"><div class="card p-3"><div class="stat">{{ d.assigned_exams }}</div>Assigned exams</div></div>
      <div class="col-6 col-md-3"><div class="card p-3"><div class="stat">{{ d.slots }}</div>Slots created</div></div>
      <div class="col-6 col-md-3"><div class="card p-3"><div class="stat">{{ d.booked_students }}</div>Students booked</div></div>
      <div class="col-6 col-md-3"><div class="card p-3"><div class="stat">{{ d.pending_evaluations }}</div>Pending evaluations</div></div>
    </div>
    <h5>My examinations</h5>
    <div class="table-responsive"><table class="table mb-0">
      <thead><tr><th>Exam</th><th>Course</th><th>Type</th><th>Slot creation window</th><th>Rubric</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <tr v-for="e in exams" :key="e.id"><td>{{ e.name }}</td><td>{{ e.course_code }}</td><td>{{ e.exam_type }}</td>
          <td>{{ e.slot_create_start }} → {{ e.slot_create_end }}</td>
          <td><span v-for="r in e.rubrics" class="badge bg-light text-dark me-1">{{ r.criterion }} ({{ r.max_marks }})</span></td>
          <td><span class="badge" :class="'bg-'+badge(e.status)">{{ e.status }}</span></td>
          <td><button v-if="e.status!=='Completed'" class="btn btn-sm btn-outline-success" @click="complete(e)">Mark completed</button></td></tr>
        <tr v-if="!exams.length"><td colspan="7" class="text-muted">No exams assigned yet.</td></tr>
      </tbody></table></div>
  </div>`
};

EMP.views.examinerSlots = {
  emits: ["go"],
  setup(props, { emit }) {
    const slots = ref([]), exams = ref([]), students = ref([]), openSlot = ref(null), editId = ref(null);
    const blank = () => ({ exam_id: "", date: "", start_time: "", end_time: "", capacity: 1, meeting_link: "" });
    const f = reactive(blank());
    const today = new Date().toISOString().slice(0, 10);

    async function load() {
      slots.value = await api("/examiner/slots");
      exams.value = await api("/examiner/exams");
    }
    async function save() {
      const call = editId.value ? () => api(`/examiner/slots/${editId.value}`, "PUT", f)
                                : () => api("/examiner/slots", "POST", f);
      if (await act(call, editId.value ? "Slot updated" : "Slot created")) { Object.assign(f, blank()); editId.value = null; load(); }
    }
    function edit(s) { editId.value = s.id; Object.assign(f, s); }
    async function remove(s) { if (confirm("Remove this slot?") && await act(() => api(`/examiner/slots/${s.id}`, "DELETE"), true)) load(); }
    async function showStudents(s) { openSlot.value = s; students.value = await api(`/examiner/slots/${s.id}/students`); }
    async function complete(s) { if (await act(() => api(`/examiner/slots/${s.id}/complete`, "PUT"), "Slot marked completed")) load(); }
    function evaluate(b) { localStorage.setItem("evalBooking", b.id); emit("go", "examinerEval"); }
    onMounted(load);
    return { slots, exams, students, openSlot, editId, f, today, save, edit, remove, showStudents, complete, evaluate, badge };
  },
  template: `
  <h4>My Slots</h4>
  <div class="card mb-4"><div class="card-body">
    <h6>{{ editId ? 'Edit slot' : 'Create a slot' }} <small class="text-muted">(allowed only while slot creation is open)</small></h6>
    <form class="row g-2" @submit.prevent="save">
      <div class="col-md-3"><select class="form-select" v-model="f.exam_id" :disabled="!!editId" required>
        <option value="" disabled>Examination</option>
        <option v-for="e in exams" :value="e.id">{{ e.name }}{{ e.can_create_slots ? '' : ' (closed)' }}</option></select></div>
      <div class="col-6 col-md-2"><input type="date" class="form-control" v-model="f.date" :min="today" required></div>
      <div class="col-3 col-md-1"><input type="time" class="form-control" v-model="f.start_time" required></div>
      <div class="col-3 col-md-1"><input type="time" class="form-control" v-model="f.end_time" required></div>
      <div class="col-4 col-md-1"><input type="number" min="1" class="form-control" v-model="f.capacity" title="Capacity" required></div>
      <div class="col-8 col-md-2"><input class="form-control" v-model="f.meeting_link" placeholder="Meeting link (optional)"></div>
      <div class="col-md-2"><button class="btn btn-primary w-100">{{ editId ? 'Update' : 'Create' }}</button></div>
    </form>
  </div></div>

  <div class="table-responsive mb-4"><table class="table mb-0">
    <thead><tr><th>Exam</th><th>Date</th><th>Time</th><th>Booked</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <tr v-for="s in slots" :key="s.id"><td>{{ s.exam }}</td><td>{{ s.date }}</td><td>{{ s.start_time }}-{{ s.end_time }}</td>
        <td>{{ s.booked }} / {{ s.capacity }}</td><td><span class="badge" :class="'bg-'+badge(s.status)">{{ s.status }}</span></td>
        <td class="text-nowrap">
          <button class="btn btn-sm btn-outline-primary me-1" @click="showStudents(s)">Students</button>
          <button class="btn btn-sm btn-outline-secondary me-1" @click="edit(s)">Edit</button>
          <button class="btn btn-sm btn-outline-danger me-1" @click="remove(s)">Delete</button>
          <button v-if="s.status!=='Completed'" class="btn btn-sm btn-outline-success" @click="complete(s)">Complete</button></td></tr>
      <tr v-if="!slots.length"><td colspan="6" class="text-muted">No slots yet.</td></tr>
    </tbody></table></div>

  <div v-if="openSlot" class="card"><div class="card-body">
    <h5>Students booked on {{ openSlot.date }} {{ openSlot.start_time }}</h5>
    <table class="table mb-0"><thead><tr><th>Name</th><th>Roll no</th><th>Status</th><th>Marks</th><th></th></tr></thead>
      <tbody>
        <tr v-for="b in students" :key="b.id"><td>{{ b.student }}</td><td>{{ b.roll_no }}</td>
          <td><span class="badge" :class="'bg-'+badge(b.status)">{{ b.status }}</span></td>
          <td>{{ b.marks ?? '—' }}</td>
          <td><button class="btn btn-sm btn-primary" @click="evaluate(b)">{{ b.evaluated ? 'Re-evaluate' : 'Evaluate' }}</button></td></tr>
        <tr v-if="!students.length"><td colspan="5" class="text-muted">No students booked.</td></tr>
      </tbody></table>
  </div></div>`
};

EMP.views.examinerEval = {
  emits: ["go"],
  setup(props, { emit }) {
    const data = ref(null), remarks = ref(""), scores = reactive({});
    const bid = localStorage.getItem("evalBooking");
    onMounted(async () => {
      data.value = await api(`/examiner/bookings/${bid}/evaluation`);
      remarks.value = data.value.remarks || "";
      data.value.rubrics.forEach((r) => (scores[r.id] = r.marks ?? ""));
    });
    const total = computed(() => Object.values(scores).reduce((a, v) => a + (parseFloat(v) || 0), 0));
    async function submit() {
      if (await act(() => api(`/examiner/bookings/${bid}/evaluate`, "POST", { scores, remarks: remarks.value }), "Marks saved")) emit("go", "examinerSlots");
    }
    return { data, remarks, scores, total, submit };
  },
  template: `
  <div v-if="data" class="row"><div class="col-md-7">
    <h4>Evaluate {{ data.booking.student }}</h4>
    <p class="text-muted">{{ data.booking.exam }} • {{ data.booking.date }} {{ data.booking.start_time }}</p>
    <div class="card"><div class="card-body"><form @submit.prevent="submit">
      <div v-for="r in data.rubrics" :key="r.id" class="mb-3">
        <label class="form-label fw-semibold">{{ r.criterion }} <small class="text-muted">(max {{ r.max_marks }}, weight {{ r.weightage }}%)</small></label>
        <div class="small text-muted">{{ r.description }}</div>
        <input type="number" step="0.5" min="0" :max="r.max_marks" class="form-control" v-model="scores[r.id]" required>
      </div>
      <label class="form-label fw-semibold">Remarks</label>
      <textarea class="form-control mb-3" rows="3" v-model="remarks" placeholder="Feedback for the student"></textarea>
      <div class="d-flex justify-content-between align-items-center">
        <div class="fs-5">Total: <b>{{ total }}</b> / {{ data.booking.max_marks }}</div>
        <button class="btn btn-primary">Submit marks</button></div>
    </form></div></div>
  </div></div>`
};
