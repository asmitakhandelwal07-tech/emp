// #24f2005575- Asmita
const MENUS = {
  admin: [["adminHome", "Dashboard"], ["adminCourses", "Courses"], ["adminExams", "Examinations"],
          ["adminExaminers", "Examiners"], ["adminStudents", "Students"], ["adminSlots", "Slots"],
          ["adminBookings", "Bookings"], ["adminSearch", "Search"]],
  examiner: [["examinerHome", "Dashboard"], ["examinerSlots", "My Slots"], ["profile", "Profile"]],
  student: [["studentHome", "Dashboard"], ["studentExams", "Examinations"],
            ["studentBookings", "My Bookings"], ["profile", "Profile"]],
};
const HOME = { admin: "adminHome", examiner: "examinerHome", student: "studentHome" };

const app = Vue.createApp({
  setup() {
    const user = ref(JSON.parse(localStorage.getItem("user") || "null"));
    const page = ref(user.value ? (localStorage.getItem("page") || HOME[user.value.role]) : "auth");
    const unread = ref(0);

    const menu = computed(() => (user.value ? MENUS[user.value.role] : []));
    const home = computed(() => (user.value ? HOME[user.value.role] : "auth"));
    const current = computed(() => EMP.views[page.value] || EMP.views[home.value]);

    function go(p) { page.value = p; localStorage.setItem("page", p); if (user.value) checkNotifications(); }

    async function checkNotifications() {
      try { unread.value = (await api("/notifications")).filter(n => !n.is_read).length; } catch (e) {}
    }
    function onLogin(res) {
      localStorage.setItem("token", res.token);
      localStorage.setItem("user", JSON.stringify(res.user));
      user.value = res.user;
      go(HOME[res.user.role]);
    }
    function logout() { localStorage.clear(); user.value = null; page.value = "auth"; }

    if (user.value) checkNotifications();
    setInterval(() => user.value && checkNotifications(), 15000);   // pick up "export ready" alerts

    return { user, page, menu, home, current, unread, msg, go, onLogin, logout };
  },
});

app.mount("#app");
