// #24f2005575- Asmita
EMP.views.adminHome = {
  setup() {
    const s = ref(null);
    const c1 = ref(null), c2 = ref(null), c3 = ref(null);
    onMounted(async () => {
      s.value = await api("/admin/stats");
      await Vue.nextTick();
      const ch = s.value.charts;
      const make = (el, type, labels, data, title) => new Chart(el, {
        type, data: { labels, datasets: [{ label: title, data,
          backgroundColor: ["#0d6efd", "#198754", "#ffc107", "#dc3545", "#6f42c1", "#20c997"] }] },
        options: { plugins: { title: { display: true, text: title } } } });
      make(c1.value, "bar", ch.bookings_per_exam.map(x => x.label), ch.bookings_per_exam.map(x => x.value), "Bookings per exam");
      make(c2.value, "bar", ch.examiner_workload.map(x => x.label), ch.examiner_workload.map(x => x.value), "Slots per examiner (workload)");
      make(c3.value, "doughnut", ["Pass", "Fail"], [ch.pass_fail.pass, ch.pass_fail.fail], "Pass / Fail");
    });
    return { s, c1, c2, c3 };
  },
  template: `
  <div v-if="s">
    <h4>Admin Dashboard</h4>
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-2" v-for="(label,key) in {courses:'Courses',exams:'Examinations',students:'Students',examiners:'Examiners',slots:'Slots',bookings:'Bookings'}">
        <div class="card p-3"><div class="stat">{{ s[key] }}</div>{{ label }}</div></div>
    </div>
    <div class="row g-3">
      <div class="col-md-5"><div class="card p-3"><canvas ref="c1"></canvas></div></div>
      <div class="col-md-4"><div class="card p-3"><canvas ref="c2"></canvas></div></div>
      <div class="col-md-3"><div class="card p-3"><canvas ref="c3"></canvas></div></div>
    </div>
  </div>`
};

EMP.views.adminCourses = {
  setup() {
    const rows = ref([]), q = ref(""), editId = ref(null);
    const f = reactive({ code: "", name: "", description: "", status: "Active" });
    const load = async () => (rows.value = await api("/admin/courses?q=" + encodeURIComponent(q.value)));
    const reset = () => { Object.assign(f, { code: "", name: "", description: "", status: "Active" }); editId.value = null; };
    async function save() {
      const call = editId.value ? () => api("/admin/courses/" + editId.value, "PUT", f) : () => api("/admin/courses", "POST", f);
      if (await act(call, "Course saved")) { reset(); load(); }
    }
    const edit = (c) => { editId.value = c.id; Object.assign(f, c); };
    const remove = async (c) => { if (confirm("Delete course " + c.code + "?") && await act(() => api("/admin/courses/" + c.id, "DELETE"), true)) load(); };
    onMounted(load);
    return { rows, q, f, editId, load, save, edit, remove, reset, badge };
  },
  template: `
  <h4>Courses</h4>
  <div class="card mb-3"><div class="card-body"><form class="row g-2" @submit.prevent="save">
    <div class="col-md-2"><input class="form-control" v-model="f.code" placeholder="Code" :disabled="!!editId" required maxlength="20"></div>
    <div class="col-md-3"><input class="form-control" v-model="f.name" placeholder="Course name" required></div>
    <div class="col-md-4"><input class="form-control" v-model="f.description" placeholder="Description"></div>
    <div class="col-md-1"><select class="form-select" v-model="f.status"><option>Active</option><option>Archived</option></select></div>
    <div class="col-md-2 d-flex gap-1"><button class="btn btn-primary flex-fill">{{ editId ? 'Update' : 'Add' }}</button>
      <button v-if="editId" type="button" class="btn btn-light" @click="reset">✕</button></div>
  </form></div></div>
  <input class="form-control mb-2" v-model="q" @input="load" placeholder="Search courses…">
  <div class="table-responsive"><table class="table mb-0">
    <thead><tr><th>ID</th><th>Code</th><th>Name</th><th>Exams</th><th>Status</th><th></th></tr></thead>
    <tbody><tr v-for="c in rows" :key="c.id"><td>{{ c.id }}</td><td>{{ c.code }}</td><td>{{ c.name }}</td><td>{{ c.exam_count }}</td>
      <td><span class="badge" :class="'bg-'+badge(c.status==='Active'?'Active':'Closed')">{{ c.status }}</span></td>
      <td class="text-nowrap"><button class="btn btn-sm btn-outline-secondary me-1" @click="edit(c)">Edit</button>
        <button class="btn btn-sm btn-outline-danger" @click="remove(c)">Delete</button></td></tr></tbody></table></div>`
};

EMP.views.adminExams = {
  setup() {
    const rows = ref([]), courses = ref([]), examiners = ref([]), q = ref("");
    const editId = ref(null), panel = ref(null);         // panel = exam whose rubric/examiners we manage
    const blank = () => ({ course_id: "", name: "", exam_type: "Viva", duration: 30, max_marks: 100, instructions: "",
      slot_create_start: "", slot_create_end: "", booking_start: "", booking_end: "" });
    const f = reactive(blank());
    const rub = reactive({ criterion: "", max_marks: 10, weightage: 0, description: "" });
    const rubrics = ref([]), chosen = ref([]);
    const statuses = ["Draft", "Slot Creation", "Booking Open", "Closed", "Completed"];

    async function load() {
      rows.value = await api("/admin/exams?q=" + encodeURIComponent(q.value));
      courses.value = await api("/admin/courses");
      examiners.value = (await api("/admin/examiners")).filter(e => e.active);
    }
    async function save() {
      const call = editId.value ? () => api("/admin/exams/" + editId.value, "PUT", f) : () => api("/admin/exams", "POST", f);
      if (await act(call, "Examination saved")) { Object.assign(f, blank()); editId.value = null; load(); }
    }
    const edit = (e) => { editId.value = e.id; Object.assign(f, e); window.scrollTo(0, 0); };
    const remove = async (e) => { if (confirm("Delete this exam?") && await act(() => api("/admin/exams/" + e.id, "DELETE"), true)) load(); };
    async function setStatus(e, status) { if (await act(() => api(`/admin/exams/${e.id}/status`, "PUT", { status }), "Status → " + status)) load(); }
    async function publish(e) { if (confirm("Publish results to students?")) act(() => api(`/admin/exams/${e.id}/publish`, "POST"), true); }
    async function manage(e) {
      panel.value = e; chosen.value = e.examiners.map(x => x.id);
      rubrics.value = await api(`/exams/${e.id}/rubrics`);
    }
    async function addRubric() {
      if (await act(() => api(`/admin/exams/${panel.value.id}/rubrics`, "POST", rub), "Criterion added")) {
        Object.assign(rub, { criterion: "", max_marks: 10, weightage: 0, description: "" });
        setTimeout(async () => (rubrics.value = await api(`/exams/${panel.value.id}/rubrics`)), 100);
      }
    }
    async function delRubric(r) { if (await act(() => api("/admin/rubrics/" + r.id, "DELETE"), true)) rubrics.value = rubrics.value.filter(x => x.id !== r.id); }
    async function saveExaminers() { if (await act(() => api(`/admin/exams/${panel.value.id}/examiners`, "PUT", { examiner_ids: chosen.value }), "Examiners assigned")) load(); }
    onMounted(load);
    return { rows, courses, examiners, q, f, editId, panel, rub, rubrics, chosen, statuses, load, save, edit, remove, setStatus, publish, manage, addRubric, delRubric, saveExaminers, badge };
  },
  template: `
  <h4>Examinations</h4>
  <div class="card mb-3"><div class="card-body">
    <h6>{{ editId ? 'Edit examination' : 'Create examination' }}</h6>
    <form class="row g-2" @submit.prevent="save">
      <div class="col-md-3"><select class="form-select" v-model="f.course_id" required><option value="" disabled>Course</option><option v-for="c in courses" :value="c.id">{{ c.code }} - {{ c.name }}</option></select></div>
      <div class="col-md-3"><input class="form-control" v-model="f.name" placeholder="Examination name" required></div>
      <div class="col-md-2"><select class="form-select" v-model="f.exam_type"><option>Viva</option><option>Practical</option><option>Project Demo</option><option>Assessment</option></select></div>
      <div class="col-6 col-md-2"><input type="number" min="1" class="form-control" v-model="f.duration" placeholder="Minutes" required></div>
      <div class="col-6 col-md-2"><input type="number" min="1" class="form-control" v-model="f.max_marks" placeholder="Max marks" required></div>
      <div class="col-6 col-md-3"><label class="small">Slot creation start</label><input type="date" class="form-control" v-model="f.slot_create_start" required></div>
      <div class="col-6 col-md-3"><label class="small">Slot creation end</label><input type="date" class="form-control" v-model="f.slot_create_end" :min="f.slot_create_start" required></div>
      <div class="col-6 col-md-3"><label class="small">Booking start</label><input type="date" class="form-control" v-model="f.booking_start" required></div>
      <div class="col-6 col-md-3"><label class="small">Booking end (cancel deadline)</label><input type="date" class="form-control" v-model="f.booking_end" :min="f.booking_start" required></div>
      <div class="col-md-10"><input class="form-control" v-model="f.instructions" placeholder="Instructions for students (shown in reminders)"></div>
      <div class="col-md-2"><button class="btn btn-primary w-100">{{ editId ? 'Update' : 'Create' }}</button></div>
    </form></div></div>

  <input class="form-control mb-2" v-model="q" @input="load" placeholder="Search exams by name, course or ID…">
  <div class="table-responsive mb-4"><table class="table mb-0 align-middle">
    <thead><tr><th>ID</th><th>Exam</th><th>Course</th><th>Type</th><th>Status (open / close)</th><th>Examiners</th><th></th></tr></thead>
    <tbody><tr v-for="e in rows" :key="e.id"><td>{{ e.id }}</td><td>{{ e.name }}<div class="small text-muted">{{ e.duration }} min • {{ e.max_marks }} marks</div></td>
      <td>{{ e.course_code }}</td><td>{{ e.exam_type }}</td>
      <td><select class="form-select form-select-sm" :value="e.status" @change="setStatus(e, $event.target.value)"><option v-for="s in statuses">{{ s }}</option></select>
        <span v-if="e.results_published" class="badge bg-success mt-1">Results published</span></td>
      <td class="small">{{ e.examiners.map(x => x.name).join(', ') || '—' }}</td>
      <td class="text-nowrap">
        <button class="btn btn-sm btn-outline-primary me-1" @click="manage(e)">Rubric / Examiners</button>
        <button class="btn btn-sm btn-outline-secondary me-1" @click="edit(e)">Edit</button>
        <button class="btn btn-sm btn-outline-success me-1" @click="publish(e)">Publish</button>
        <button class="btn btn-sm btn-outline-danger" @click="remove(e)">Delete</button></td></tr></tbody></table></div>

  <div v-if="panel" class="row g-3">
    <div class="col-md-7"><div class="card"><div class="card-body">
      <h5>Rubric - {{ panel.name }}</h5>
      <table class="table table-sm"><thead><tr><th>Criterion</th><th>Max</th><th>Weight %</th><th></th></tr></thead>
        <tbody><tr v-for="r in rubrics" :key="r.id"><td>{{ r.criterion }}<div class="small text-muted">{{ r.description }}</div></td><td>{{ r.max_marks }}</td><td>{{ r.weightage }}</td>
          <td><button class="btn btn-sm btn-outline-danger" @click="delRubric(r)">✕</button></td></tr>
          <tr v-if="!rubrics.length"><td colspan="4" class="text-muted">No criteria yet.</td></tr></tbody></table>
      <form class="row g-2" @submit.prevent="addRubric">
        <div class="col-md-4"><input class="form-control" v-model="rub.criterion" placeholder="Criterion" required></div>
        <div class="col-4 col-md-2"><input type="number" min="1" class="form-control" v-model="rub.max_marks" required></div>
        <div class="col-4 col-md-2"><input type="number" min="0" max="100" class="form-control" v-model="rub.weightage"></div>
        <div class="col-4 col-md-4"><button class="btn btn-primary w-100">Add criterion</button></div>
        <div class="col-12"><input class="form-control" v-model="rub.description" placeholder="Description (optional)"></div>
      </form></div></div></div>
    <div class="col-md-5"><div class="card"><div class="card-body">
      <h5>Assigned examiners</h5>
      <div v-for="x in examiners" :key="x.id" class="form-check"><input class="form-check-input" type="checkbox" :value="x.id" v-model="chosen" :id="'ex'+x.id">
        <label class="form-check-label" :for="'ex'+x.id">{{ x.name }} <small class="text-muted">{{ x.department }}</small></label></div>
      <button class="btn btn-primary mt-3" @click="saveExaminers">Save</button>
    </div></div></div>
  </div>`
};

EMP.views.adminExaminers = {
  setup() {
    const rows = ref([]), q = ref(""), created = ref(null);
    const f = reactive({ name: "", email: "", department: "", contact: "" });
    const load = async () => (rows.value = await api("/admin/examiners?q=" + encodeURIComponent(q.value)));
    async function add() {
      const r = await act(() => api("/admin/examiners", "POST", f), "Examiner created - credentials e-mailed");
      if (r) { created.value = r; Object.assign(f, { name: "", email: "", department: "", contact: "" }); load(); }
    }
    async function setStatus(u, status) { if (await act(() => api("/admin/examiners/" + u.id, "PUT", { status }), "Status updated")) load(); }
    onMounted(load);
    return { rows, q, f, created, load, add, setStatus, badge };
  },
  template: `
  <h4>Examiners</h4>
  <div class="card mb-3"><div class="card-body"><form class="row g-2" @submit.prevent="add">
    <div class="col-md-3"><input class="form-control" v-model="f.name" placeholder="Name" required></div>
    <div class="col-md-3"><input type="email" class="form-control" v-model="f.email" placeholder="Email" required></div>
    <div class="col-md-2"><input class="form-control" v-model="f.department" placeholder="Department"></div>
    <div class="col-md-2"><input class="form-control" v-model="f.contact" placeholder="Contact" pattern="[0-9+ -]{7,15}"></div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Add examiner</button></div>
  </form>
  <div v-if="created" class="alert alert-info mt-3 mb-0">Created <b>{{ created.examiner.email }}</b>. Temporary password (also e-mailed): <code>{{ created.temp_password }}</code></div>
  </div></div>
  <input class="form-control mb-2" v-model="q" @input="load" placeholder="Search examiners by name, email or ID…">
  <div class="table-responsive"><table class="table mb-0">
    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Department</th><th>Status</th><th></th></tr></thead>
    <tbody><tr v-for="u in rows" :key="u.id"><td>{{ u.id }}</td><td>{{ u.name }}</td><td>{{ u.email }}</td><td>{{ u.department }}</td>
      <td><span class="badge" :class="'bg-'+badge(u.status)">{{ u.status }}</span></td>
      <td><button v-if="u.status==='Active'" class="btn btn-sm btn-outline-danger" @click="setStatus(u,'Inactive')">Deactivate</button>
          <button v-else class="btn btn-sm btn-outline-success" @click="setStatus(u,'Active')">Approve / Activate</button></td></tr></tbody></table></div>`
};

EMP.views.adminStudents = {
  setup() {
    const rows = ref([]), q = ref("");
    const load = async () => (rows.value = await api("/admin/students?q=" + encodeURIComponent(q.value)));
    const toggle = async (u) => { if (await act(() => api(`/admin/students/${u.id}/active`, "PUT"), "Updated")) load(); };
    onMounted(load);
    return { rows, q, load, toggle };
  },
  template: `
  <h4>Students</h4>
  <input class="form-control mb-2" v-model="q" @input="load" placeholder="Search by name, email, roll no or ID…">
  <div class="table-responsive"><table class="table mb-0">
    <thead><tr><th>ID</th><th>Name</th><th>Roll no</th><th>Email</th><th>Phone</th><th>Account</th><th></th></tr></thead>
    <tbody><tr v-for="u in rows" :key="u.id"><td>{{ u.id }}</td><td>{{ u.name }}</td><td>{{ u.roll_no }}</td><td>{{ u.email }}</td><td>{{ u.phone }}</td>
      <td><span class="badge" :class="u.active?'bg-success':'bg-danger'">{{ u.active ? 'Active' : 'Blocked' }}</span></td>
      <td><button class="btn btn-sm btn-outline-secondary" @click="toggle(u)">{{ u.active ? 'Block' : 'Unblock' }}</button></td></tr></tbody></table></div>`
};

EMP.views.adminSlots = {
  setup() {
    const rows = ref([]), exams = ref([]), examFilter = ref("");
    async function load() {
      rows.value = await api("/admin/slots" + (examFilter.value ? "?exam_id=" + examFilter.value : ""));
      exams.value = await api("/admin/exams");
    }
    const examinersFor = (s) => (exams.value.find(e => e.id === s.exam_id) || { examiners: [] }).examiners;
    async function change(s, id) {
      if (await act(() => api(`/admin/slots/${s.id}/examiner`, "PUT", { examiner_id: id }), "Examiner changed")) load();
    }
    onMounted(load);
    return { rows, exams, examFilter, load, examinersFor, change, badge };
  },
  template: `
  <h4>All Examiner Slots</h4>
  <select class="form-select mb-2" v-model="examFilter" @change="load"><option value="">All examinations</option><option v-for="e in exams" :value="e.id">{{ e.name }}</option></select>
  <div class="table-responsive"><table class="table mb-0 align-middle">
    <thead><tr><th>ID</th><th>Exam</th><th>Date</th><th>Time</th><th>Seats</th><th>Status</th><th>Examiner (change if needed)</th></tr></thead>
    <tbody><tr v-for="s in rows" :key="s.id"><td>{{ s.id }}</td><td>{{ s.exam }}</td><td>{{ s.date }}</td><td>{{ s.start_time }}-{{ s.end_time }}</td>
      <td>{{ s.booked }}/{{ s.capacity }}</td><td><span class="badge" :class="'bg-'+badge(s.status)">{{ s.status }}</span></td>
      <td><select class="form-select form-select-sm" :value="s.examiner_id" @change="change(s, $event.target.value)">
        <option v-for="x in examinersFor(s)" :value="x.id">{{ x.name }}</option></select></td></tr></tbody></table></div>`
};

EMP.views.adminBookings = {
  setup() {
    const rows = ref([]), q = ref(""), status = ref(""), moving = ref(null), options = ref([]), target = ref("");
    const load = async () => (rows.value = await api(`/admin/bookings?q=${encodeURIComponent(q.value)}&status=${status.value}`));
    async function startMove(b) {
      moving.value = b; target.value = "";
      options.value = (await api("/admin/slots?exam_id=" + b.exam_id)).filter(s => s.id !== b.slot_id && s.available_seats > 0 && !["Cancelled", "Completed"].includes(s.status));
    }
    async function move() {
      if (await act(() => api(`/admin/bookings/${moving.value.id}/reschedule`, "PUT", { slot_id: target.value }), "Booking rescheduled")) { moving.value = null; load(); }
    }
    onMounted(load);
    return { rows, q, status, moving, options, target, load, startMove, move, badge };
  },
  template: `
  <h4>All Bookings <small class="text-muted">(complete history)</small></h4>
  <div class="row g-2 mb-2">
    <div class="col-md-8"><input class="form-control" v-model="q" @input="load" placeholder="Search by student, exam or booking ID…"></div>
    <div class="col-md-4"><select class="form-select" v-model="status" @change="load"><option value="">All statuses</option><option>Booked</option><option>Completed</option><option>Cancelled</option></select></div>
  </div>
  <div v-if="moving" class="alert alert-warning">
    Reschedule <b>{{ moving.student }}</b> ({{ moving.exam }}) to:
    <div class="input-group mt-2"><select class="form-select" v-model="target"><option value="" disabled>Choose a slot</option>
      <option v-for="s in options" :value="s.id">{{ s.date }} {{ s.start_time }} - {{ s.examiner }} ({{ s.available_seats }} seats)</option></select>
      <button class="btn btn-primary" :disabled="!target" @click="move">Move</button><button class="btn btn-light" @click="moving=null">Cancel</button></div>
  </div>
  <div class="table-responsive"><table class="table mb-0">
    <thead><tr><th>ID</th><th>Student</th><th>Exam</th><th>Date</th><th>Time</th><th>Examiner</th><th>Status</th><th>Marks</th><th></th></tr></thead>
    <tbody><tr v-for="b in rows" :key="b.id"><td>{{ b.id }}</td><td>{{ b.student }}</td><td>{{ b.exam }}</td><td>{{ b.date }}</td><td>{{ b.start_time }}</td><td>{{ b.examiner }}</td>
      <td><span class="badge" :class="'bg-'+badge(b.status)">{{ b.status }}</span></td><td>{{ b.marks ?? '—' }}</td>
      <td><button v-if="b.status==='Booked'" class="btn btn-sm btn-outline-primary" @click="startMove(b)">Reschedule</button></td></tr></tbody></table></div>`
};

EMP.views.adminSearch = {
  setup() {
    const q = ref(""), r = ref(null);
    const go = async () => (r.value = await api("/admin/search?q=" + encodeURIComponent(q.value)));
    return { q, r, go };
  },
  template: `
  <h4>Search everything</h4>
  <form class="input-group mb-3" @submit.prevent="go"><input class="form-control" v-model="q" placeholder="Student, examiner, examination or booking (name / ID)" required><button class="btn btn-primary">Search</button></form>
  <div v-if="r">
    <h6>Students ({{ r.students.length }})</h6><ul class="list-group mb-3"><li class="list-group-item" v-for="u in r.students">#{{ u.id }} {{ u.name }} - {{ u.email }}</li></ul>
    <h6>Examiners ({{ r.examiners.length }})</h6><ul class="list-group mb-3"><li class="list-group-item" v-for="u in r.examiners">#{{ u.id }} {{ u.name }} - {{ u.department }}</li></ul>
    <h6>Examinations ({{ r.exams.length }})</h6><ul class="list-group mb-3"><li class="list-group-item" v-for="e in r.exams">#{{ e.id }} {{ e.name }} ({{ e.status }})</li></ul>
    <h6>Bookings ({{ r.bookings.length }})</h6><ul class="list-group"><li class="list-group-item" v-for="b in r.bookings">#{{ b.id }} {{ b.student }} → {{ b.exam }} on {{ b.date }} [{{ b.status }}]</li></ul>
  </div>`
};
