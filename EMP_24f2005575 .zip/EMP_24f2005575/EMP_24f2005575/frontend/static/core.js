// #24f2005575- Asmita
const { ref, reactive, onMounted, computed } = Vue;

window.EMP = { views: {} };   // every page component is stored here and used by main.js

const msg = reactive({ text: "", type: "success" });
function toast(text, type = "success") {
  msg.text = text; msg.type = type;
  setTimeout(() => (msg.text = ""), 3500);
}

async function api(path, method = "GET", body = null) {
  const headers = { "Content-Type": "application/json" };
  const token = localStorage.getItem("token");
  if (token) headers["Authorization"] = "Bearer " + token;
  const res = await fetch("/api" + path, { method, headers, body: body ? JSON.stringify(body) : null });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && token) {          // token expired -> back to login
    localStorage.clear(); location.reload();
  }
  if (!res.ok) throw new Error(data.error || "Something went wrong");
  return data;
}

async function act(promiseFn, successMsg) {
  try {
    const data = await promiseFn();
    if (successMsg) toast(successMsg === true ? (data.message || "Done") : successMsg);
    return data;
  } catch (e) { toast(e.message, "danger"); return null; }
}

async function download(url) {
  const res = await fetch(url, { headers: { Authorization: "Bearer " + localStorage.getItem("token") } });
  if (!res.ok) return toast("Download failed", "danger");
  const blob = await res.blob();
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = url.split("/").pop();
  a.click();
}

const badge = (s) => ({ Booked: "primary", Completed: "success", Cancelled: "secondary", Available: "success",
  Full: "warning", Draft: "secondary", "Slot Creation": "info", "Booking Open": "primary",
  Closed: "dark", Active: "success", Inactive: "danger" }[s] || "secondary");

EMP.views.auth = {
  emits: ["login"],
  setup(props, { emit }) {
    const mode = ref("login");
    const f = reactive({ name: "", email: "", password: "", phone: "", roll_no: "" });
    async function submit() {
      if (mode.value === "register") {
        const r = await act(() => api("/register", "POST", f), true);
        if (r) mode.value = "login";
        return;
      }
      const r = await act(() => api("/login", "POST", { email: f.email, password: f.password }));
      if (r) emit("login", r);
    }
    return { mode, f, submit };
  },
  template: `
  <div class="row justify-content-center"><div class="col-md-5">
    <div class="text-center mb-4"><h2>Examination Management Portal</h2>
      <p class="text-muted">Admin, Examiner and Student login</p></div>
    <div class="card"><div class="card-body">
      <ul class="nav nav-pills mb-3">
        <li class="nav-item"><a class="nav-link pointer" :class="{active:mode==='login'}" @click="mode='login'">Login</a></li>
        <li class="nav-item"><a class="nav-link pointer" :class="{active:mode==='register'}" @click="mode='register'">Student Register</a></li>
      </ul>
      <form @submit.prevent="submit">
        <template v-if="mode==='register'">
          <input class="form-control mb-2" v-model="f.name" placeholder="Full name" required>
          <input class="form-control mb-2" v-model="f.roll_no" placeholder="Roll number (optional)">
          <input class="form-control mb-2" v-model="f.phone" placeholder="Phone (optional)" pattern="[0-9+ -]{7,15}" title="Enter a valid phone number">
        </template>
        <input class="form-control mb-2" type="email" v-model="f.email" placeholder="Email" required>
        <input class="form-control mb-3" type="password" v-model="f.password" placeholder="Password (min 6 characters)" minlength="6" required>
        <button class="btn btn-primary w-100">{{ mode==='login' ? 'Login' : 'Create account' }}</button>
      </form>
      <p class="small text-muted mt-3 mb-0">Examiner accounts are created by the Admin. Admin is pre-created.</p>
    </div></div>
  </div></div>`
};

EMP.views.notifications = {
  setup() {
    const items = ref([]);
    onMounted(async () => { items.value = await api("/notifications"); await api("/notifications/read", "POST"); });
    return { items, download };
  },
  template: `
  <h4>Notifications</h4>
  <div v-if="!items.length" class="text-muted">Nothing yet.</div>
  <ul class="list-group">
    <li v-for="n in items" :key="n.id" class="list-group-item d-flex justify-content-between align-items-center">
      <div>{{ n.message }}<div class="small text-muted">{{ n.created_at }}</div></div>
      <button v-if="n.link" class="btn btn-sm btn-success" @click="download(n.link)">Download</button>
    </li>
  </ul>`
};

EMP.views.profile = {
  setup() {
    const f = reactive({ name: "", phone: "", roll_no: "", password: "" });
    const role = ref("");
    onMounted(async () => { const u = await api("/me"); Object.assign(f, u, { password: "" }); role.value = u.role; });
    const save = () => act(() => api("/me", "PUT", f), true).then(() => (f.password = ""));
    return { f, role, save };
  },
  template: `
  <div class="row"><div class="col-md-6"><h4>My Profile</h4>
  <div class="card"><div class="card-body"><form @submit.prevent="save">
    <label class="form-label">Name</label><input class="form-control mb-2" v-model="f.name" required>
    <label class="form-label">Phone</label><input class="form-control mb-2" v-model="f.phone" pattern="[0-9+ -]{7,15}" title="Enter a valid phone number">
    <template v-if="role==='student'"><label class="form-label">Roll number</label><input class="form-control mb-2" v-model="f.roll_no"></template>
    <label class="form-label">New password (leave empty to keep)</label><input type="password" class="form-control mb-3" v-model="f.password" minlength="6">
    <button class="btn btn-primary">Save</button>
  </form></div></div></div></div>`
};
