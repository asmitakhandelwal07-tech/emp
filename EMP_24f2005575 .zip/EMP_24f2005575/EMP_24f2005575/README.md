# Examination Management Portal (EMP) - MAD-II

A web app where the **Admin** sets up courses, examinations and rubrics, **Examiners** create
time slots and evaluate students, and **Students** book a slot, appear for the exam and see their
published results.

## Tech stack (only what the problem statement allows)

| Part       | Used                                                                                                        |
| ---------- | ----------------------------------------------------------------------------------------------------------- |
| API        | Flask (+ Flask-SQLAlchemy as ORM)                                                                           |
| UI         | Vue 3 loaded from a CDN (no build step) - Jinja2 is used **only** for the entry page `index.html`           |
| Styling    | Bootstrap 5 (only CSS framework)                                                                            |
| Charts     | Chart.js (admin dashboard)                                                                                  |
| Database   | SQLite - tables are created by code (`db.create_all()`), admin is created by code                           |
| Cache      | Redis                                                                                                       |
| Batch jobs | Celery + Celery Beat with Redis as broker                                                                   |
| Auth       | Signed token (`itsdangerous`, comes with Flask) sent as `Authorization: Bearer <token>` + role based access |
| Mail       | Python's built-in `smtplib` (falls back to saving mails in `backend/outbox/`)                               |

## Folder structure

```
EMP/
├── backend/
│   ├── app.py              # creates app, tables, admin; serves the UI
│   ├── config.py           # all settings (env-variable overridable)
│   ├── models.py           # database tables
│   ├── auth.py             # login / register / token / role check
│   ├── routes_admin.py     # /api/admin/...
│   ├── routes_examiner.py  # /api/examiner/...
│   ├── routes_student.py   # /api/student/... (+ cached public APIs)
│   ├── cache.py            # Redis cache helper (cached / invalidate)
│   ├── tasks.py            # Celery jobs + beat schedule
│   ├── mailer.py           # e-mail helper
│   ├── utils.py            # date parsing, run_task
│   └── seed_demo.py        # optional demo data
├── frontend/
│   ├── index.html          # the only Jinja2 template (entry point)
│   └── static/             # core.js, admin.js, examiner.js, student.js, main.js, style.css
├── requirements.txt
└── README.md
```

## How to run (local machine)

```bash
# 1. create a virtual env and install
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 2. (optional but recommended) start Redis - needed for caching and Celery
redis-server                      # on Windows use WSL

# 3. start the web app  (creates emp.db + the admin automatically)
cd backend
python app.py                     # open http://localhost:5000

# 4. (optional) load demo data
python seed_demo.py

# 5. Celery - two more terminals, inside backend/
celery -A tasks.celery worker --loglevel=info
celery -A tasks.celery beat   --loglevel=info
```

If Redis is not running the app still works (caching is skipped, and the CSV export runs in a
background thread) - so you can always demo the main features.

**Default logins**

| Role                            | Email            | Password    |
| ------------------------------- | ---------------- | ----------- |
| Admin (pre-created)             | admin@emp.com    | admin123    |
| Examiner (after `seed_demo.py`) | examiner@emp.com | examiner123 |
| Student (after `seed_demo.py`)  | student@emp.com  | student123  |

Students can also register themselves. Examiners are created by the Admin (a temporary
password is e-mailed - and shown on screen so it can be demonstrated without SMTP).

## Typical flow to demo

1. **Admin** → add a course → create an examination with the 4 timeline dates → add rubric criteria →
   add an examiner → _Rubric / Examiners_ → assign the examiner → set status **Slot Creation**.
2. **Examiner** → _My Slots_ → create slots.
3. **Admin** → set status **Booking Open**.
4. **Student** → _Examinations_ → _View slots_ → **Book**. (Try booking twice / a full slot - it is refused.)
5. **Examiner** → _My Slots_ → _Students_ → **Evaluate** with the rubric → _Complete_.
6. **Admin** → **Publish** results → **Student** sees marks and remarks.
7. **Student** dashboard → _Export CSV_ → a notification appears with the download link.

## Business rules (where they live in code)

| Rule                                                        | File / function                                        |
| ----------------------------------------------------------- | ------------------------------------------------------ |
| Slots only during slot-creation period (status + dates)     | `routes_examiner.create_slot`                          |
| Slots editable/removable only before booking starts         | `routes_examiner.update_slot / delete_slot`            |
| Booking only while booking is open (status + dates)         | `routes_student.book`                                  |
| One booking per exam / no duplicates                        | `routes_student.book` (rule 3)                         |
| No overbooking, auto "Full" status                          | `routes_student.book`, `models.Slot.refresh_status`    |
| Cancel only before booking deadline                         | `routes_student.cancel`                                |
| Examiner evaluates only own slot's students                 | `routes_examiner.evaluate`                             |
| Marks within each rubric's maximum                          | `routes_examiner.evaluate`                             |
| Students see marks only after Admin publishes               | `models.Booking.to_dict`, `routes_student.my_bookings` |
| Admin reschedule booking / change examiner                  | `routes_admin.reschedule / change_examiner`            |
| History kept - exams/courses with bookings can't be deleted | `routes_admin.remove_exam / remove_course`             |

## Celery jobs (`backend/tasks.py`)

| Job                    | Type           | When                                                                                                                                                  |
| ---------------------- | -------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| `send_daily_reminders` | Scheduled      | every day 08:00 - e-mail + in-app (+ Google Chat webhook if `GCHAT_WEBHOOK` is set) for exams today/tomorrow: name, date/time, examiner, instructions |
| `monthly_report`       | Scheduled      | 1st of every month 07:00 - HTML report e-mailed to admin (also saved in `backend/reports/`)                                                           |
| `export_history_csv`   | User triggered | Student clicks _Export_ → CSV saved in `backend/exports/` → notification with download link                                                           |

Test a job right away without waiting for the schedule:

```bash
cd backend
python -c "from tasks import send_daily_reminders as t; t.run()"
python -c "from tasks import monthly_report as t; t.run()"
```

To send real mails set `SMTP_HOST`, `SMTP_USER`, `SMTP_PASSWORD`, `MAIL_FROM` as environment variables.

## Redis caching (`backend/cache.py`)

| Key                  | What                               | Expiry |
| -------------------- | ---------------------------------- | ------ |
| `exams:public`       | examination list shown to students | 60 s   |
| `rubrics:<exam_id>`  | rubric of an exam                  | 300 s  |
| `schedule:<exam_id>` | bookable slots of an exam          | 30 s   |

Expiry = `SETEX`. Whenever the admin/examiner/student changes data, `invalidate()` deletes the
related keys so nobody sees stale data.

## ER diagram

```
 User(id, name, email, password_hash, role, phone, roll_no, active)
   │ 1
   ├──1 ExaminerProfile(user_id, department, contact, status)
   │
 Course(id, code, name, description, status)
   │ 1
   └──* Exam(id, course_id, name, exam_type, duration, max_marks, instructions,
   │        slot_create_start/end, booking_start/end, status, results_published)
   │      │ 1
   │      ├──* Rubric(id, exam_id, criterion, max_marks, weightage, description)
   │      ├──* Slot(id, exam_id, examiner_id→User, date, start_time, end_time,
   │      │         capacity, meeting_link, status)
   │      │      │ 1
   │      │      └──* Booking(id, student_id→User, slot_id, exam_id, booking_date, status)
   │      │              │ 1
   │      │              └──1 Evaluation(id, booking_id, student_id, examiner_id,
   │      │                              total_marks, remarks, evaluation_date, status)
   │      │                      │ 1
   │      │                      └──* EvaluationScore(id, evaluation_id, rubric_id, marks)
   │      └──*──* User(examiner)   via table exam_examiners(exam_id, examiner_id)
 Notification(id, user_id, message, link, is_read, created_at)
```

## API endpoints

All endpoints are under `/api`. Token header: `Authorization: Bearer <token>`.

**Auth (all roles)**
`POST /register` (student) · `POST /login` · `GET /me` · `PUT /me` · `GET /notifications` · `POST /notifications/read`

**Admin** (`/api/admin`)
`GET /stats` · `GET|POST /courses` · `PUT|DELETE /courses/<id>` · `GET|POST /exams` · `PUT|DELETE /exams/<id>` ·
`PUT /exams/<id>/status` (open/close slot creation & booking) · `PUT /exams/<id>/examiners` · `POST /exams/<id>/publish` ·
`POST /exams/<id>/rubrics` · `PUT|DELETE /rubrics/<id>` · `GET|POST /examiners` · `PUT /examiners/<id>` ·
`GET /students` · `PUT /students/<id>/active` · `GET /slots` · `PUT /slots/<id>/examiner` ·
`GET /bookings` · `PUT /bookings/<id>/reschedule` · `GET /search?q=`

**Examiner** (`/api/examiner`)
`GET /dashboard` · `GET /exams` · `PUT /exams/<id>/complete` · `GET|POST /slots` · `PUT|DELETE /slots/<id>` ·
`GET /slots/<id>/students` · `PUT /slots/<id>/complete` · `GET /bookings/<id>/evaluation` · `POST /bookings/<id>/evaluate`

**Student** (`/api`)
`GET /student/dashboard` · `GET /student/exams?q=&type=&status=` · `GET /student/exams/<id>/slots` ·
`POST /student/slots/<id>/book` · `POST /student/bookings/<id>/cancel` · `GET /student/bookings` ·
`POST /student/export` · `GET /student/export/<file>` · `GET /exams/<id>/rubrics` (cached)

## Extra features beyond the core list

Chart.js analytics (bookings per exam, examiner workload, pass/fail) · in-app notifications (booking,
cancellation, reschedule, results, export ready) · overlap check for an examiner's slots ·
PWA manifest ("Add to home screen") · responsive Bootstrap layout · HTML5 + backend validation.
