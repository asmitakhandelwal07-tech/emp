#24f2005575- Asmita
#24f2005575- Asmita
import os
import smtplib
from datetime import datetime
from email.mime.text import MIMEText
from config import Config


def send_mail(to, subject, body, html=False):
    if Config.SMTP_HOST:
        try:
            msg = MIMEText(body, "html" if html else "plain")
            msg["Subject"], msg["From"], msg["To"] = subject, Config.MAIL_FROM, to
            with smtplib.SMTP(Config.SMTP_HOST, Config.SMTP_PORT, timeout=10) as s:
                s.starttls()
                if Config.SMTP_USER:
                    s.login(Config.SMTP_USER, Config.SMTP_PASSWORD)
                s.sendmail(Config.MAIL_FROM, [to], msg.as_string())
            return True
        except Exception as e:
            print("[mail] failed:", e)
            return False

    os.makedirs(Config.OUTBOX_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    ext = "html" if html else "txt"
    path = os.path.join(Config.OUTBOX_DIR, f"{stamp}_{to}.{ext}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"To: {to}\nSubject: {subject}\n\n{body}")
    print(f"[mail] (no SMTP) saved to {path}")
    return True
