#24f2005575- Asmita
from datetime import date
from flask import Blueprint, request, jsonify, g
from models import db, Exam, Rubric, Slot, Booking, Evaluation, EvaluationScore, notify
from auth import login_required
from cache import invalidate
from utils import parse_date, parse_time, in_window

examiner_bp = Blueprint("examiner", __name__, url_prefix="/api/examiner")
examiner_only = login_required("examiner")


def _my_slot_or_none(sid):
    """Return the slot only if it belongs to the logged-in examiner."""
    s = db.session.get(Slot, sid)
    return s if s and s.examiner_id == g.user.id else None


def _pending_evaluations(examiner_id):
    """Bookings in this examiner's slots that are not evaluated yet."""
    rows = (Booking.query.join(Slot, Booking.slot_id == Slot.id)
            .filter(Slot.examiner_id == examiner_id, Booking.status != "Cancelled").all())
    return [b for b in rows if b.evaluation is None]


@examiner_bp.get("/dashboard")
@examiner_only
def dashboard():
    slots = Slot.query.filter_by(examiner_id=g.user.id).all()
    return jsonify(
        assigned_exams=len(g.user.assigned_exams),
        slots=len(slots),
        booked_students=sum(s.booked_count for s in slots),
        pending_evaluations=len(_pending_evaluations(g.user.id)))


@examiner_bp.get("/exams")
@examiner_only
def my_exams():
    """Exams assigned to me, together with the rubric (needed for the slot / evaluation forms)."""
    out = []
    for e in g.user.assigned_exams:
        d = e.to_dict()
        d["rubrics"] = [r.to_dict() for r in e.rubrics]
        d["can_create_slots"] = e.status == "Slot Creation" and in_window(e.slot_create_start, e.slot_create_end)
        out.append(d)
    return jsonify(out)


@examiner_bp.put("/exams/<int:eid>/complete")
@examiner_only
def complete_exam(eid):
    """Examiner marks the examination as completed (all my students must be evaluated first)."""
    e = db.get_or_404(Exam, eid)
    if e not in g.user.assigned_exams:
        return jsonify(error="This exam is not assigned to you"), 403
    pending = [b for b in _pending_evaluations(g.user.id) if b.exam_id == eid]
    if pending:
        return jsonify(error=f"{len(pending)} student(s) still need evaluation"), 400
    e.status = "Completed"
    db.session.commit()
    invalidate("exams:", "schedule:")
    return jsonify(e.to_dict())


@examiner_bp.get("/slots")
@examiner_only
def my_slots():
    slots = Slot.query.filter_by(examiner_id=g.user.id).order_by(Slot.date, Slot.start_time).all()
    return jsonify([s.to_dict() for s in slots])


def _validate_slot(d, exam, ignore_slot_id=None):
    """Returns (date, start, end, capacity, error)."""
    dt, st, en = parse_date(d.get("date")), parse_time(d.get("start_time")), parse_time(d.get("end_time"))
    try:
        cap = int(d.get("capacity", 1))
    except (TypeError, ValueError):
        cap = 0
    if not (dt and st and en):
        return None, None, None, None, "Date, start time and end time are required"
    if st >= en:
        return None, None, None, None, "End time must be after start time"
    if cap < 1:
        return None, None, None, None, "Capacity must be at least 1"
    if dt < date.today():
        return None, None, None, None, "Slot date cannot be in the past"
    for other in Slot.query.filter_by(examiner_id=g.user.id, date=dt).all():
        if other.id != ignore_slot_id and other.status != "Cancelled" \
                and st < other.end_time and en > other.start_time:
            return None, None, None, None, "This overlaps with another slot of yours"
    return dt, st, en, cap, None


@examiner_bp.post("/slots")
@examiner_only
def create_slot():
    d = request.get_json() or {}
    exam = db.session.get(Exam, d.get("exam_id") or 0)
    if not exam or exam not in g.user.assigned_exams:
        return jsonify(error="This exam is not assigned to you"), 403
    if exam.status != "Slot Creation" or not in_window(exam.slot_create_start, exam.slot_create_end):
        return jsonify(error="Slot creation is not open for this examination"), 400
    dt, st, en, cap, err = _validate_slot(d, exam)
    if err:
        return jsonify(error=err), 400
    s = Slot(exam_id=exam.id, examiner_id=g.user.id, date=dt, start_time=st, end_time=en,
             capacity=cap, meeting_link=d.get("meeting_link"))
    db.session.add(s)
    db.session.commit()
    invalidate("schedule:")
    return jsonify(s.to_dict()), 201


@examiner_bp.put("/slots/<int:sid>")
@examiner_only
def update_slot(sid):
    s = _my_slot_or_none(sid)
    if not s:
        return jsonify(error="Slot not found"), 404
    if s.exam.status not in ("Draft", "Slot Creation") or s.bookings:
        return jsonify(error="Slots can only be changed before student booking starts"), 400
    d = request.get_json() or {}
    d.setdefault("date", s.date.isoformat())
    d.setdefault("start_time", s.start_time.strftime("%H:%M"))
    d.setdefault("end_time", s.end_time.strftime("%H:%M"))
    d.setdefault("capacity", s.capacity)
    dt, st, en, cap, err = _validate_slot(d, s.exam, ignore_slot_id=s.id)
    if err:
        return jsonify(error=err), 400
    s.date, s.start_time, s.end_time, s.capacity = dt, st, en, cap
    s.meeting_link = d.get("meeting_link", s.meeting_link)
    db.session.commit()
    invalidate("schedule:")
    return jsonify(s.to_dict())


@examiner_bp.delete("/slots/<int:sid>")
@examiner_only
def delete_slot(sid):
    s = _my_slot_or_none(sid)
    if not s:
        return jsonify(error="Slot not found"), 404
    if s.exam.status not in ("Draft", "Slot Creation") or s.bookings:
        return jsonify(error="Slots can only be removed before student booking starts"), 400
    db.session.delete(s)
    db.session.commit()
    invalidate("schedule:")
    return jsonify(message="Slot removed")


@examiner_bp.get("/slots/<int:sid>/students")
@examiner_only
def slot_students(sid):
    """Students booked into one of MY slots."""
    s = _my_slot_or_none(sid)
    if not s:
        return jsonify(error="Slot not found"), 404
    return jsonify([b.to_dict() for b in s.bookings if b.status != "Cancelled"])


@examiner_bp.put("/slots/<int:sid>/complete")
@examiner_only
def complete_slot(sid):
    """After the viva/exam is over, mark the slot (and its bookings) as Completed."""
    s = _my_slot_or_none(sid)
    if not s:
        return jsonify(error="Slot not found"), 404
    s.status = "Completed"
    for b in s.bookings:
        if b.status == "Booked":
            b.status = "Completed"
    db.session.commit()
    invalidate("schedule:")
    return jsonify(s.to_dict())


@examiner_bp.get("/bookings/<int:bid>/evaluation")
@examiner_only
def get_evaluation(bid):
    """Rubric + any marks already given (used to fill the evaluation form)."""
    b = db.get_or_404(Booking, bid)
    if b.slot.examiner_id != g.user.id:
        return jsonify(error="This student is not booked in your slot"), 403
    ev = b.evaluation
    given = {sc.rubric_id: sc.marks for sc in ev.scores} if ev else {}
    return jsonify(booking=b.to_dict(),
                   rubrics=[{**r.to_dict(), "marks": given.get(r.id)} for r in b.exam.rubrics],
                   remarks=ev.remarks if ev else "")


@examiner_bp.post("/bookings/<int:bid>/evaluate")
@examiner_only
def evaluate(bid):
    """Submit rubric-wise marks + remarks. Can be re-submitted to correct marks."""
    b = db.get_or_404(Booking, bid)
    if b.slot.examiner_id != g.user.id:
        return jsonify(error="You can only evaluate students booked in your own slots"), 403
    if b.status == "Cancelled":
        return jsonify(error="This booking was cancelled"), 400
    d = request.get_json() or {}
    scores = d.get("scores") or {}
    rubrics = b.exam.rubrics
    if not rubrics:
        return jsonify(error="Admin has not defined a rubric for this exam yet"), 400

    total, clean = 0.0, []
    for r in rubrics:
        try:
            m = float(scores.get(str(r.id), scores.get(r.id)))
        except (TypeError, ValueError):
            return jsonify(error=f"Enter marks for '{r.criterion}'"), 400
        if m < 0 or m > r.max_marks:
            return jsonify(error=f"'{r.criterion}' marks must be between 0 and {r.max_marks}"), 400
        clean.append((r.id, m))
        total += m

    ev = b.evaluation or Evaluation(booking_id=b.id, student_id=b.student_id,
                                    examiner_id=g.user.id)
    ev.total_marks, ev.remarks, ev.status = total, (d.get("remarks") or "").strip(), "Evaluated"
    ev.scores = [EvaluationScore(rubric_id=rid, marks=m) for rid, m in clean]
    b.status = "Completed"            # evaluated => booking is completed
    db.session.add(ev)
    db.session.commit()
    return jsonify(message="Marks saved", total=total)
