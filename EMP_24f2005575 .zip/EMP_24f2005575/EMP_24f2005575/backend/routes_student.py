#24f2005575- Asmita
import os
from datetime import date
from flask import Blueprint, request, jsonify, g, send_from_directory
from models import db, Exam, Rubric, Slot, Booking, notify
from auth import login_required
from cache import cached, invalidate
from utils import in_window, run_task
from config import Config

student_bp = Blueprint("student", __name__, url_prefix="/api")
student_only = login_required("student")


@student_bp.get("/exams/<int:eid>/rubrics")
@login_required()
def rubrics(eid):
    data = cached(f"rubrics:{eid}",
                  lambda: [r.to_dict() for r in Rubric.query.filter_by(exam_id=eid).all()],
                  ttl=300)
    return jsonify(data)


@student_bp.get("/student/exams")
@student_only
def exams():
    """Browse / search / filter examinations. The full list is cached; filtering is done in memory."""
    all_exams = cached("exams:public",
                       lambda: [e.to_dict() for e in Exam.query.filter(Exam.status != "Draft").all()],
                       ttl=60)
    q = (request.args.get("q") or "").strip().lower()
    etype, status = request.args.get("type"), request.args.get("status")
    out = []
    for e in all_exams:
        if q and q not in e["name"].lower() and q not in (e["course"] or "").lower() \
                and q not in (e["course_code"] or "").lower():
            continue
        if etype and e["exam_type"] != etype:
            continue
        if status and e["status"] != status:
            continue
        out.append(e)
    mine = {b.exam_id for b in Booking.query.filter_by(student_id=g.user.id)
            .filter(Booking.status != "Cancelled")}
    for e in out:
        e["already_booked"] = e["id"] in mine
    return jsonify(out)


@student_bp.get("/student/exams/<int:eid>/slots")
@student_only
def exam_slots(eid):
    """Examination schedule: all slots of an exam that can still be booked."""
    def load():
        slots = Slot.query.filter_by(exam_id=eid).order_by(Slot.date, Slot.start_time).all()
        return [s.to_dict() for s in slots if s.status != "Cancelled"]
    return jsonify(cached(f"schedule:{eid}", load, ttl=30))


@student_bp.post("/student/slots/<int:sid>/book")
@student_only
def book(sid):
    slot = db.get_or_404(Slot, sid)
    exam = slot.exam

    if exam.status != "Booking Open" or not in_window(exam.booking_start, exam.booking_end):
        return jsonify(error="Slot booking is closed for this examination"), 400
    if slot.status in ("Cancelled", "Completed"):
        return jsonify(error="This slot is not available"), 400
    dup = Booking.query.filter_by(student_id=g.user.id, exam_id=exam.id) \
        .filter(Booking.status != "Cancelled").first()
    if dup:
        return jsonify(error="You already have a booking for this examination"), 400
    db.session.refresh(slot)
    if slot.available_seats < 1:
        return jsonify(error="This slot is full"), 400

    b = Booking(student_id=g.user.id, slot_id=slot.id, exam_id=exam.id, status="Booked")
    db.session.add(b)
    db.session.flush()
    slot.refresh_status()                      # becomes 'Full' automatically when capacity reached
    notify(g.user.id, f"Booking confirmed: {exam.name} on {slot.date} at {slot.start_time:%H:%M}")
    db.session.commit()
    invalidate("schedule:")
    return jsonify(message="Slot booked successfully!", booking=b.to_dict()), 201


@student_bp.post("/student/bookings/<int:bid>/cancel")
@student_only
def cancel(bid):
    b = db.get_or_404(Booking, bid)
    if b.student_id != g.user.id:                  # students can only touch their own booking
        return jsonify(error="Booking not found"), 404
    if b.status != "Booked":
        return jsonify(error="Only active bookings can be cancelled"), 400
    if b.exam.booking_end and date.today() > b.exam.booking_end:
        return jsonify(error="The booking deadline has passed"), 400
    b.status = "Cancelled"
    db.session.flush()
    b.slot.refresh_status()                        # seat freed -> slot may become Available again
    notify(g.user.id, f"Booking cancelled: {b.exam.name}")
    db.session.commit()
    invalidate("schedule:")
    return jsonify(message="Booking cancelled")


@student_bp.get("/student/bookings")
@student_only
def my_bookings():
    """Complete history of MY bookings. Marks are hidden until results are published."""
    rows = Booking.query.filter_by(student_id=g.user.id).order_by(Booking.id.desc()).all()
    return jsonify([b.to_dict(show_result=b.exam.results_published) | {
        "results_published": b.exam.results_published} for b in rows])


@student_bp.get("/student/dashboard")
@student_only
def dashboard():
    mine = Booking.query.filter_by(student_id=g.user.id).all()
    today = date.today()
    upcoming = [b for b in mine if b.status == "Booked" and b.slot.date >= today]
    results = [b for b in mine if b.exam.results_published and b.evaluation]
    open_exams = Exam.query.filter_by(status="Booking Open").all()
    open_slots = sum(s.available_seats > 0 and s.status == "Available"
                     for e in open_exams for s in e.slots)
    return jsonify(
        available_exams=len(open_exams), available_slots=open_slots,
        upcoming=[b.to_dict() for b in sorted(upcoming, key=lambda b: (b.slot.date, b.slot.start_time))],
        booked=len([b for b in mine if b.status == "Booked"]),
        results=[b.to_dict() for b in results])


@student_bp.post("/student/export")
@student_only
def export_history():
    """
    User-triggered async job: returns immediately, Celery builds the CSV in the
    background and adds a notification (with download link) when it is ready.
    """
    from tasks import export_history_csv
    how = run_task(export_history_csv, g.user.id)
    return jsonify(message="Export started. You'll get a notification when it's ready.", via=how), 202


@student_bp.get("/student/export/<filename>")
@student_only
def download_export(filename):
    if not filename.startswith(f"student_{g.user.id}_") or "/" in filename:
        return jsonify(error="Not allowed"), 403
    return send_from_directory(Config.EXPORT_DIR, filename, as_attachment=True)
