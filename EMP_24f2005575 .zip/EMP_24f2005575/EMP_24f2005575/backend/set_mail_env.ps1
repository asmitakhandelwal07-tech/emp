#24f2005575- Asmita
$GMAIL_ADDRESS = "yourname@gmail.com"
$APP_PASSWORD  = "abcdefghijklmnop"   # 16-character Google App Password (spaces will be automatically removed)

$env:SMTP_HOST = "smtp.gmail.com"
$env:SMTP_PORT = "587"
$env:SMTP_USER = $GMAIL_ADDRESS
$env:SMTP_PASSWORD = $APP_PASSWORD.Replace(" ", "")
$env:MAIL_FROM = $GMAIL_ADDRESS

if ($GMAIL_ADDRESS -eq "yourname@gmail.com") {
    Write-Host "[WARNING] Please edit set_mail_env.ps1 and replace 'yourname@gmail.com' and the App Password with your actual Gmail credentials." -ForegroundColor Yellow
} else {
    Write-Host "`n[SUCCESS] SMTP environment variables loaded for current session!" -ForegroundColor Green
    Write-Host "  SMTP_HOST     : $env:SMTP_HOST" -ForegroundColor Cyan
    Write-Host "  SMTP_PORT     : $env:SMTP_PORT" -ForegroundColor Cyan
    Write-Host "  SMTP_USER     : $env:SMTP_USER" -ForegroundColor Cyan
    Write-Host "  MAIL_FROM     : $env:MAIL_FROM" -ForegroundColor Cyan
    Write-Host "  SMTP_PASSWORD : [Configured - length: $($env:SMTP_PASSWORD.Length)]`n" -ForegroundColor Cyan
}
