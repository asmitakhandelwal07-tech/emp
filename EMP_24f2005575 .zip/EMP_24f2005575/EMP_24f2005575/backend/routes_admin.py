#24f2005575- Asmita
import secrets
from flask import Blueprint, request, jsonify
from sqlalchemy import or_, func
from werkzeug.security import generate_password_hash
from models import (db, User, ExaminerProfile, Course, Exam, Rubric, Slot, Booking,
                    Evaluation, notify)
from auth import login_required
from cache import invalidate
from mailer import send_mail
from utils import parse_date

admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")
admin_only = login_required("admin")

EXAM_STATUSES = ["Draft", "Slot Creation", "Booking Open", "Closed", "Completed"]
EXAM_TYPES = ["Viva", "Practical", "Project Demo", "Assessment"]


@admin_bp.get("/stats")
@admin_only
def stats():
    """Counts for the dashboard cards + data for the Chart.js charts."""
    per_exam = (db.session.query(Exam.name, func.count(Booking.id))
                .outerjoin(Booking, (Booking.exam_id == Exam.id) & (Booking.status != "Cancelled"))
                .group_by(Exam.id).all())
    workload = (db.session.query(User.name, func.count(Slot.id))
                .outerjoin(Slot, Slot.examiner_id == User.id)
                .filter(User.role == "examiner").group_by(User.id).all())
    passed = failed = 0
    for ev in Evaluation.query.all():
        mx = ev.booking.exam.max_marks or 1
        if ev.total_marks / mx >= 0.4:
            passed += 1
        else:
            failed += 1
    return jsonify(
        courses=Course.query.count(), exams=Exam.query.count(),
        students=User.query.filter_by(role="student").count(),
        examiners=User.query.filter_by(role="examiner").count(),
        slots=Slot.query.count(), bookings=Booking.query.count(),
        charts={"bookings_per_exam": [{"label": n, "value": c} for n, c in per_exam],
                "examiner_workload": [{"label": n, "value": c} for n, c in workload],
                "pass_fail": {"pass": passed, "fail": failed}})


@admin_bp.get("/courses")
@admin_only
def courses():
    q = (request.args.get("q") or "").strip()
    query = Course.query
    if q:
        query = query.filter(or_(Course.name.ilike(f"%{q}%"), Course.code.ilike(f"%{q}%")))
    return jsonify([c.to_dict() for c in query.order_by(Course.id.desc()).all()])


@admin_bp.post("/courses")
@admin_only
def add_course():
    d = request.get_json() or {}
    code, name = (d.get("code") or "").strip().upper(), (d.get("name") or "").strip()
    if not code or not name:
        return jsonify(error="Course code and name are required"), 400
    if Course.query.filter_by(code=code).first():
        return jsonify(error="A course with this code already exists"), 409
    c = Course(code=code, name=name, description=d.get("description"),
               status=d.get("status", "Active"))
    db.session.add(c)
    db.session.commit()
    return jsonify(c.to_dict()), 201


@admin_bp.put("/courses/<int:cid>")
@admin_only
def edit_course(cid):
    c = db.get_or_404(Course, cid)
    d = request.get_json() or {}
    c.name = (d.get("name") or c.name).strip()
    c.description = d.get("description", c.description)
    c.status = d.get("status", c.status)
    db.session.commit()
    invalidate("exams:")
    return jsonify(c.to_dict())


@admin_bp.delete("/courses/<int:cid>")
@admin_only
def remove_course(cid):
    c = db.get_or_404(Course, cid)
    if Booking.query.join(Exam, Booking.exam_id == Exam.id).filter(Exam.course_id == cid).first():
        return jsonify(error="Course has booking history. Archive it instead of deleting."), 400
    db.session.delete(c)
    db.session.commit()
    invalidate("exams:", "rubrics:", "schedule:")
    return jsonify(message="Course removed")


def _fill_exam(e, d):
    """Copy + validate form data into an Exam. Returns an error string or None."""
    e.name = (d.get("name") or e.name or "").strip()
    e.exam_type = d.get("exam_type", e.exam_type or "Viva")
    e.instructions = d.get("instructions", e.instructions)
    try:
        e.duration = int(d.get("duration", e.duration or 30))
        e.max_marks = int(d.get("max_marks", e.max_marks or 100))
    except (TypeError, ValueError):
        return "Duration and maximum marks must be numbers"
    if not e.name:
        return "Examination name is required"
    if e.exam_type not in EXAM_TYPES:
        return "Invalid examination type"
    if e.duration <= 0 or e.max_marks <= 0:
        return "Duration and marks must be positive"
    for f in ("slot_create_start", "slot_create_end", "booking_start", "booking_end"):
        if f in d:
            setattr(e, f, parse_date(d[f]))
    if e.slot_create_start and e.slot_create_end and e.slot_create_start > e.slot_create_end:
        return "Slot creation end date must be after its start date"
    if e.booking_start and e.booking_end and e.booking_start > e.booking_end:
        return "Booking end date must be after its start date"
    return None


@admin_bp.get("/exams")
@admin_only
def exams():
    q = (request.args.get("q") or "").strip()
    query = Exam.query.join(Course)
    if q:
        query = query.filter(or_(Exam.name.ilike(f"%{q}%"), Course.name.ilike(f"%{q}%"),
                                 Exam.id == (int(q) if q.isdigit() else -1)))
    return jsonify([e.to_dict() for e in query.order_by(Exam.id.desc()).all()])


@admin_bp.post("/exams")
@admin_only
def add_exam():
    d = request.get_json() or {}
    if not db.session.get(Course, d.get("course_id") or 0):
        return jsonify(error="Please choose a valid course"), 400
    e = Exam(course_id=d["course_id"], status="Draft")
    err = _fill_exam(e, d)
    if err:
        return jsonify(error=err), 400
    db.session.add(e)
    db.session.commit()
    invalidate("exams:")
    return jsonify(e.to_dict()), 201


@admin_bp.put("/exams/<int:eid>")
@admin_only
def edit_exam(eid):
    e = db.get_or_404(Exam, eid)
    err = _fill_exam(e, request.get_json() or {})
    if err:
        return jsonify(error=err), 400
    db.session.commit()
    invalidate("exams:", "schedule:")
    return jsonify(e.to_dict())


@admin_bp.delete("/exams/<int:eid>")
@admin_only
def remove_exam(eid):
    e = db.get_or_404(Exam, eid)
    if Booking.query.filter_by(exam_id=eid).first():
        return jsonify(error="Exam already has bookings. Close it instead of deleting."), 400
    db.session.delete(e)
    db.session.commit()
    invalidate("exams:", "rubrics:", "schedule:")
    return jsonify(message="Examination removed")


@admin_bp.put("/exams/<int:eid>/status")
@admin_only
def set_status(eid):
    """
    This one endpoint is how the admin OPENS / CLOSES slot creation and booking:
       'Slot Creation'  -> examiners may create slots
       'Booking Open'   -> students may book
       'Closed'         -> nobody can create/book
    """
    e = db.get_or_404(Exam, eid)
    status = (request.get_json() or {}).get("status")
    if status not in EXAM_STATUSES:
        return jsonify(error="Invalid status"), 400
    e.status = status
    db.session.commit()
    invalidate("exams:", "schedule:")
    return jsonify(e.to_dict())


@admin_bp.put("/exams/<int:eid>/examiners")
@admin_only
def assign_examiners(eid):
    """Choose which examiners are assigned to this exam."""
    e = db.get_or_404(Exam, eid)
    ids = (request.get_json() or {}).get("examiner_ids", [])
    e.examiners = User.query.filter(User.id.in_(ids), User.role == "examiner").all()
    db.session.commit()
    invalidate("exams:")
    return jsonify(e.to_dict())


@admin_bp.post("/exams/<int:eid>/publish")
@admin_only
def publish_results(eid):
    """Publish results: students can now see marks + remarks; they are notified & e-mailed."""
    e = db.get_or_404(Exam, eid)
    e.results_published = True
    count = 0
    for b in Booking.query.filter_by(exam_id=eid).all():
        if b.evaluation:
            notify(b.student_id, f"Results published for {e.name}")
            send_mail(b.student.email, f"Results published: {e.name}",
                      f"Hi {b.student.name},\n\nYour result for {e.name} is now available. "
                      f"Log in to the portal to see your marks and remarks.")
            count += 1
    db.session.commit()
    return jsonify(message=f"Results published. {count} students notified.")


@admin_bp.post("/exams/<int:eid>/rubrics")
@admin_only
def add_rubric(eid):
    db.get_or_404(Exam, eid)
    d = request.get_json() or {}
    try:
        mx = int(d.get("max_marks"))
        w = float(d.get("weightage") or 0)
    except (TypeError, ValueError):
        return jsonify(error="Max marks and weightage must be numbers"), 400
    if not (d.get("criterion") or "").strip() or mx <= 0:
        return jsonify(error="Criterion name and positive max marks are required"), 400
    r = Rubric(exam_id=eid, criterion=d["criterion"].strip(), max_marks=mx,
               weightage=w, description=d.get("description"))
    db.session.add(r)
    db.session.commit()
    invalidate("rubrics:")
    return jsonify(r.to_dict()), 201


@admin_bp.put("/rubrics/<int:rid>")
@admin_only
def edit_rubric(rid):
    r = db.get_or_404(Rubric, rid)
    d = request.get_json() or {}
    r.criterion = d.get("criterion", r.criterion)
    r.description = d.get("description", r.description)
    try:
        r.max_marks = int(d.get("max_marks", r.max_marks))
        r.weightage = float(d.get("weightage", r.weightage))
    except (TypeError, ValueError):
        return jsonify(error="Numbers expected"), 400
    db.session.commit()
    invalidate("rubrics:")
    return jsonify(r.to_dict())


@admin_bp.delete("/rubrics/<int:rid>")
@admin_only
def remove_rubric(rid):
    r = db.get_or_404(Rubric, rid)
    db.session.delete(r)
    db.session.commit()
    invalidate("rubrics:")
    return jsonify(message="Rubric removed")


@admin_bp.get("/examiners")
@admin_only
def examiners():
    q = (request.args.get("q") or "").strip()
    query = User.query.filter_by(role="examiner")
    if q:
        query = query.filter(or_(User.name.ilike(f"%{q}%"), User.email.ilike(f"%{q}%"),
                                 User.id == (int(q) if q.isdigit() else -1)))
    return jsonify([u.to_dict() for u in query.order_by(User.id.desc()).all()])


@admin_bp.post("/examiners")
@admin_only
def add_examiner():
    """Admin creates the examiner; a temporary password is e-mailed to them."""
    d = request.get_json() or {}
    name, email = (d.get("name") or "").strip(), (d.get("email") or "").strip().lower()
    if not name or "@" not in email:
        return jsonify(error="Name and a valid email are required"), 400
    if User.query.filter_by(email=email).first():
        return jsonify(error="This email is already used"), 409
    temp_pw = secrets.token_urlsafe(6)
    u = User(name=name, email=email, role="examiner", phone=d.get("contact"),
             password_hash=generate_password_hash(temp_pw))
    u.profile = ExaminerProfile(department=d.get("department"), contact=d.get("contact"),
                                status="Active")
    db.session.add(u)
    db.session.commit()
    send_mail(email, "Your Examiner account - EMP",
              f"Hello {name},\n\nAn examiner account was created for you.\n"
              f"Email: {email}\nTemporary password: {temp_pw}\n\nPlease log in and change it.")
    return jsonify(examiner=u.to_dict(), temp_password=temp_pw), 201


@admin_bp.put("/examiners/<int:uid>")
@admin_only
def edit_examiner(uid):
    """Edit details, approve / deactivate (status + login access)."""
    u = db.get_or_404(User, uid)
    if u.role != "examiner":
        return jsonify(error="Not an examiner"), 400
    d = request.get_json() or {}
    u.name = d.get("name", u.name)
    u.profile.department = d.get("department", u.profile.department)
    if "status" in d:
        u.profile.status = d["status"]
        u.active = d["status"] == "Active"   # inactive examiners cannot log in
    db.session.commit()
    return jsonify(u.to_dict())


@admin_bp.get("/students")
@admin_only
def students():
    q = (request.args.get("q") or "").strip()
    query = User.query.filter_by(role="student")
    if q:
        query = query.filter(or_(User.name.ilike(f"%{q}%"), User.email.ilike(f"%{q}%"),
                                 User.roll_no.ilike(f"%{q}%"),
                                 User.id == (int(q) if q.isdigit() else -1)))
    return jsonify([u.to_dict() for u in query.order_by(User.id.desc()).all()])


@admin_bp.put("/students/<int:uid>/active")
@admin_only
def toggle_student(uid):
    u = db.get_or_404(User, uid)
    if u.role != "student":
        return jsonify(error="Not a student"), 400
    u.active = not u.active
    db.session.commit()
    return jsonify(u.to_dict())


@admin_bp.get("/slots")
@admin_only
def all_slots():
    query = Slot.query
    if request.args.get("exam_id"):
        query = query.filter_by(exam_id=request.args["exam_id"])
    return jsonify([s.to_dict() for s in query.order_by(Slot.date, Slot.start_time).all()])


@admin_bp.put("/slots/<int:sid>/examiner")
@admin_only
def change_examiner(sid):
    """Exceptional situation: hand a slot (and its students) to another examiner."""
    s = db.get_or_404(Slot, sid)
    try:
        new = db.session.get(User, int((request.get_json() or {}).get("examiner_id") or 0))
    except (TypeError, ValueError):
        new = None
    if not new or new.role != "examiner" or not new.active:
        return jsonify(error="Choose an active examiner"), 400
    if new not in s.exam.examiners:
        return jsonify(error="That examiner is not assigned to this examination"), 400
    s.examiner_id = new.id
    for b in s.bookings:
        if b.status != "Cancelled":
            notify(b.student_id, f"Examiner for {s.exam.name} changed to {new.name}")
    notify(new.id, f"You were assigned a slot for {s.exam.name} on {s.date}")
    db.session.commit()
    invalidate("schedule:")
    return jsonify(s.to_dict())


@admin_bp.get("/bookings")
@admin_only
def all_bookings():
    """All bookings = complete history. ?q= searches student / exam / booking id."""
    q = (request.args.get("q") or "").strip()
    query = (Booking.query.join(User, Booking.student_id == User.id)
             .join(Exam, Booking.exam_id == Exam.id))
    if q:
        query = query.filter(or_(User.name.ilike(f"%{q}%"), Exam.name.ilike(f"%{q}%"),
                                 Booking.id == (int(q) if q.isdigit() else -1)))
    if request.args.get("status"):
        query = query.filter(Booking.status == request.args["status"])
    return jsonify([b.to_dict() for b in query.order_by(Booking.id.desc()).all()])


@admin_bp.put("/bookings/<int:bid>/reschedule")
@admin_only
def reschedule(bid):
    """Move a student's booking to another slot of the SAME exam (if seats are free)."""
    b = db.get_or_404(Booking, bid)
    try:
        new_slot = db.session.get(Slot, int((request.get_json() or {}).get("slot_id") or 0))
    except (TypeError, ValueError):
        new_slot = None
    if b.status != "Booked":
        return jsonify(error="Only active bookings can be rescheduled"), 400
    if not new_slot or new_slot.exam_id != b.exam_id:
        return jsonify(error="Pick a slot of the same examination"), 400
    if new_slot.status in ("Cancelled", "Completed") or new_slot.available_seats < 1:
        return jsonify(error="That slot has no free seats"), 400
    old = b.slot
    b.slot_id = new_slot.id
    db.session.flush()
    old.refresh_status()
    new_slot.refresh_status()
    notify(b.student_id, f"Your {b.exam.name} was rescheduled to {new_slot.date} {new_slot.start_time:%H:%M}")
    db.session.commit()
    invalidate("schedule:")
    return jsonify(b.to_dict())


@admin_bp.get("/search")
@admin_only
def search():
    """One search box that looks in students, examiners, exams and bookings."""
    q = (request.args.get("q") or "").strip()
    if not q:
        return jsonify(students=[], examiners=[], exams=[], bookings=[])
    like, num = f"%{q}%", (int(q) if q.isdigit() else -1)
    users = User.query.filter(or_(User.name.ilike(like), User.email.ilike(like), User.id == num))
    bookings = (Booking.query.join(User, Booking.student_id == User.id)
                .join(Exam, Booking.exam_id == Exam.id)
                .filter(or_(User.name.ilike(like), Exam.name.ilike(like), Booking.id == num)))
    return jsonify(
        students=[u.to_dict() for u in users.filter(User.role == "student").limit(20)],
        examiners=[u.to_dict() for u in users.filter(User.role == "examiner").limit(20)],
        exams=[e.to_dict() for e in Exam.query.filter(or_(Exam.name.ilike(like), Exam.id == num)).limit(20)],
        bookings=[b.to_dict() for b in bookings.limit(20)])
