#24f2005575- Asmita
#24f2005575- Asmita
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production")
    TOKEN_MAX_AGE = 60 * 60 * 8

    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "emp.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    CACHE_DEFAULT_TTL = 60

    ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@emp.com")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")

    SMTP_HOST = os.getenv("SMTP_HOST", "")
    SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USER = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    MAIL_FROM = os.getenv("MAIL_FROM", "emp@example.com")

    GCHAT_WEBHOOK = os.getenv("GCHAT_WEBHOOK", "")

    EXPORT_DIR = os.path.join(BASE_DIR, "exports")
    REPORT_DIR = os.path.join(BASE_DIR, "reports")
    OUTBOX_DIR = os.path.join(BASE_DIR, "outbox")
