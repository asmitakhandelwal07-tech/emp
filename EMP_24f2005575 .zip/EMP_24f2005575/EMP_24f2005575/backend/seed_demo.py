#24f2005575- Asmita
from datetime import date, timedelta, time
from werkzeug.security import generate_password_hash
from app import create_app
from models import db, User, ExaminerProfile, Course, Exam, Rubric, Slot

app = create_app()
with app.app_context():
    if Course.query.first():
        print("Demo data already exists - nothing to do.")
        raise SystemExit

    course = Course(code="CS101", name="Introduction to Programming", description="Basics of Python")
    exam = Exam(course=course, name="Python Viva", exam_type="Viva", duration=15, max_marks=20,
                instructions="Keep your ID card and be online 5 minutes early.",
                slot_create_start=date.today(), slot_create_end=date.today() + timedelta(days=30),
                booking_start=date.today(), booking_end=date.today() + timedelta(days=30),
                status="Slot Creation")
    exam.rubrics = [Rubric(criterion="Concept clarity", max_marks=10, weightage=50, description="Understanding of basics"),
                    Rubric(criterion="Code explanation", max_marks=10, weightage=50, description="Explains own code")]

    examiner = User(name="Dr. Sharma", email="examiner@emp.com", role="examiner",
                    password_hash=generate_password_hash("examiner123"))
    examiner.profile = ExaminerProfile(department="Computer Science", contact="9999999999", status="Active")
    student = User(name="Asha Student", email="student@emp.com", role="student", roll_no="21F1000001",
                   password_hash=generate_password_hash("student123"))
    exam.examiners = [examiner]
    db.session.add_all([course, exam, examiner, student])
    db.session.flush()

    for i, hour in enumerate((10, 11)):
        db.session.add(Slot(exam_id=exam.id, examiner_id=examiner.id,
                            date=date.today() + timedelta(days=2),
                            start_time=time(hour, 0), end_time=time(hour, 15), capacity=2))
    db.session.commit()
    exam.status = "Booking Open"   # admin would normally open booking from the UI
    db.session.commit()
    print("Demo data created.")
    print("  admin    : admin@emp.com    / admin123")
    print("  examiner : examiner@emp.com / examiner123")
    print("  student  : student@emp.com  / student123")
