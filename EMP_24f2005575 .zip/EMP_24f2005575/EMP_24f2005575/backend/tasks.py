#24f2005575- Asmita
import csv
import os
from datetime import date, datetime, timedelta
from celery import Celery
from celery.schedules import crontab
from sqlalchemy import func
from config import Config

celery = Celery("emp", broker=Config.REDIS_URL, backend=Config.REDIS_URL)

celery.conf.beat_schedule = {
    "daily-exam-reminder": {                       # every day at 08:00
        "task": "tasks.send_daily_reminders",
        "schedule": crontab(hour=8, minute=0),
    },
    "monthly-exam-report": {                       # 1st of every month at 07:00
        "task": "tasks.monthly_report",
        "schedule": crontab(day_of_month=1, hour=7, minute=0),
    },
}
celery.conf.timezone = "Asia/Kolkata"


def _app():
    """Celery runs outside a web request, so we create the Flask app to reach the database."""
    from app import create_app
    return create_app()


@celery.task(name="tasks.send_daily_reminders")
def send_daily_reminders():
    """Remind every student who has an exam today or tomorrow."""
    from models import Booking, notify, db
    from mailer import send_mail
    app = _app()
    with app.app_context():
        today, tomorrow = date.today(), date.today() + timedelta(days=1)
        count = 0
        for b in Booking.query.filter_by(status="Booked").all():
            if b.slot.date not in (today, tomorrow):
                continue
            when = "today" if b.slot.date == today else "tomorrow"
            text = (f"Reminder: {b.exam.name} ({b.exam.course.name}) is {when}, "
                    f"{b.slot.date} {b.slot.start_time:%H:%M}-{b.slot.end_time:%H:%M}. "
                    f"Examiner: {b.slot.examiner.name}. "
                    f"Instructions: {b.exam.instructions or 'None'}")
            notify(b.student_id, text)
            send_mail(b.student.email, f"Exam reminder: {b.exam.name}", text)
            _google_chat(text)
            count += 1
        db.session.commit()
        print(f"[reminder] {count} reminders sent")
        return count


def _google_chat(text):
    """Optional: also post to a Google Chat space through an incoming webhook."""
    if not Config.GCHAT_WEBHOOK:
        return
    import json, urllib.request
    try:
        req = urllib.request.Request(Config.GCHAT_WEBHOOK, data=json.dumps({"text": text}).encode(),
                                     headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=10)
    except Exception as e:
        print("[gchat] failed:", e)


@celery.task(name="tasks.monthly_report")
def monthly_report():
    """Build an HTML report of LAST month and e-mail it to the admin."""
    from models import Booking, Evaluation, Slot, User
    from mailer import send_mail
    app = _app()
    with app.app_context():
        first_this = date.today().replace(day=1)
        last_end = first_this - timedelta(days=1)
        first_last = last_end.replace(day=1)

        bookings = [b for b in Booking.query.all()
                    if first_last <= b.slot.date <= last_end and b.status != "Cancelled"]
        completed = [b for b in bookings if b.status == "Completed"]
        evaluated = [b for b in bookings if b.evaluation]
        pending = [b for b in bookings if not b.evaluation]
        exams_conducted = {b.exam_id for b in completed}
        examiners = {}
        for b in bookings:
            examiners[b.slot.examiner.name] = examiners.get(b.slot.examiner.name, 0) + 1
        top = sorted(examiners.items(), key=lambda x: -x[1])[:5]

        rows = "".join(f"<tr><td>{n}</td><td>{c}</td></tr>" for n, c in top) \
            or "<tr><td colspan=2>No activity</td></tr>"
        html = f"""
        <html><body style="font-family:Arial">
        <h2>Monthly Examination Report - {first_last:%B %Y}</h2>
        <table border="1" cellpadding="6" cellspacing="0">
          <tr><td>Examinations conducted</td><td>{len(exams_conducted)}</td></tr>
          <tr><td>Participants (students with a booking)</td><td>{len({b.student_id for b in bookings})}</td></tr>
          <tr><td>Students evaluated</td><td>{len({b.student_id for b in evaluated})}</td></tr>
          <tr><td>Completed bookings</td><td>{len(completed)}</td></tr>
          <tr><td>Pending evaluations</td><td>{len(pending)}</td></tr>
          <tr><td>Examiners involved</td><td>{len(examiners)}</td></tr>
        </table>
        <h3>Most active examiners</h3>
        <table border="1" cellpadding="6" cellspacing="0"><tr><th>Examiner</th><th>Bookings handled</th></tr>{rows}</table>
        </body></html>"""

        os.makedirs(Config.REPORT_DIR, exist_ok=True)           # keep a copy on disk too
        path = os.path.join(Config.REPORT_DIR, f"report_{first_last:%Y_%m}.html")
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        admin = User.query.filter_by(role="admin").first()
        send_mail(admin.email, f"Monthly Examination Report - {first_last:%B %Y}", html, html=True)
        print("[report] saved", path)
        return path


@celery.task(name="tasks.export_history_csv")
def export_history_csv(student_id):
    """Write the student's exam history to a CSV file, then notify the student."""
    from models import Booking, notify, db
    app = _app()
    with app.app_context():
        os.makedirs(Config.EXPORT_DIR, exist_ok=True)
        filename = f"student_{student_id}_{datetime.now():%Y%m%d_%H%M%S}.csv"
        path = os.path.join(Config.EXPORT_DIR, filename)
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["Student ID", "Examination Name", "Course", "Examination Date",
                        "Examiner", "Marks Obtained", "Booking Status"])
            for b in Booking.query.filter_by(student_id=student_id).order_by(Booking.id).all():
                marks = b.evaluation.total_marks if (b.evaluation and b.exam.results_published) else ""
                w.writerow([student_id, b.exam.name, b.exam.course.name, b.slot.date,
                            b.slot.examiner.name, marks, b.status])
        notify(student_id, "Your examination history CSV is ready - click to download",
               link=f"/api/student/export/{filename}")
        db.session.commit()
        return filename
