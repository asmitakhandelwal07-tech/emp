#24f2005575- Asmita
import threading
from datetime import date, time, datetime


def parse_date(value):
    """'2026-11-20' -> date object (None if empty / invalid)."""
    try:
        return date.fromisoformat(value) if value else None
    except (ValueError, TypeError):
        return None


def parse_time(value):
    """'14:30' -> time object (None if invalid)."""
    try:
        return time.fromisoformat(value) if value else None
    except (ValueError, TypeError):
        return None


def in_window(start, end):
    """True if today falls between start and end (inclusive). Missing dates = no limit."""
    today = date.today()
    if start and today < start:
        return False
    if end and today > end:
        return False
    return True


def run_task(task, *args):
    """
    Start a Celery task asynchronously (task.delay).
    If Redis / the Celery broker is not running, fall back to a background
    thread so the demo still works on a laptop without the worker.
    """
    try:
        task.apply_async(args=args, retry=False)   # normal path: goes to Redis -> Celery worker
        return "celery"
    except Exception as e:
        print("[celery unavailable, using thread fallback]", e)
        threading.Thread(target=task.run, args=args, daemon=True).start()
        return "thread"
