#24f2005575- Asmita
#24f2005575- Asmita
from functools import wraps
from flask import Blueprint, request, jsonify, g, current_app
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User

auth_bp = Blueprint("auth", __name__, url_prefix="/api")


def make_token(user):
    s = URLSafeTimedSerializer(current_app.config["SECRET_KEY"])
    return s.dumps({"id": user.id, "role": user.role})


def login_required(*roles):
    def wrapper(fn):
        @wraps(fn)
        def inner(*args, **kwargs):
            header = request.headers.get("Authorization", "")
            if not header.startswith("Bearer "):
                return jsonify(error="Login required"), 401
            s = URLSafeTimedSerializer(current_app.config["SECRET_KEY"])
            try:
                data = s.loads(header[7:], max_age=current_app.config["TOKEN_MAX_AGE"])
            except (BadSignature, SignatureExpired):
                return jsonify(error="Session expired, please log in again"), 401
            user = db.session.get(User, data["id"])
            if not user or not user.active:
                return jsonify(error="Account not found or deactivated"), 401
            if roles and user.role not in roles:
                return jsonify(error="You are not allowed to do this"), 403
            g.user = user
            return fn(*args, **kwargs)
        return inner
    return wrapper


@auth_bp.post("/register")
def register():
    d = request.get_json() or {}
    name, email, pw = (d.get("name") or "").strip(), (d.get("email") or "").strip().lower(), d.get("password") or ""
    if not name or "@" not in email or len(pw) < 6:
        return jsonify(error="Enter a name, a valid email and a password of 6+ characters"), 400
    if User.query.filter_by(email=email).first():
        return jsonify(error="This email is already registered"), 409
    u = User(name=name, email=email, role="student", phone=d.get("phone"),
             roll_no=d.get("roll_no"), password_hash=generate_password_hash(pw))
    db.session.add(u)
    db.session.commit()
    return jsonify(message="Registered! You can log in now."), 201


@auth_bp.post("/login")
def login():
    d = request.get_json() or {}
    u = User.query.filter_by(email=(d.get("email") or "").strip().lower()).first()
    if not u or not check_password_hash(u.password_hash, d.get("password") or ""):
        return jsonify(error="Wrong email or password"), 401
    if not u.active:
        return jsonify(error="Your account is deactivated. Contact the admin."), 403
    return jsonify(token=make_token(u), user=u.to_dict())


@auth_bp.get("/me")
@login_required()
def me():
    return jsonify(g.user.to_dict())


@auth_bp.put("/me")
@login_required()
def update_me():
    d = request.get_json() or {}
    u = g.user
    if d.get("name"):
        u.name = d["name"].strip()
    u.phone = d.get("phone", u.phone)
    if u.role == "student":
        u.roll_no = d.get("roll_no", u.roll_no)
    if d.get("password"):
        if len(d["password"]) < 6:
            return jsonify(error="Password must be 6+ characters"), 400
        u.password_hash = generate_password_hash(d["password"])
    db.session.commit()
    return jsonify(message="Profile updated", user=u.to_dict())


@auth_bp.get("/notifications")
@login_required()
def notifications():
    from models import Notification
    rows = (Notification.query.filter_by(user_id=g.user.id)
            .order_by(Notification.id.desc()).limit(30).all())
    return jsonify([n.to_dict() for n in rows])


@auth_bp.post("/notifications/read")
@login_required()
def notifications_read():
    from models import Notification
    Notification.query.filter_by(user_id=g.user.id, is_read=False).update({"is_read": True})
    db.session.commit()
    return jsonify(message="ok")
