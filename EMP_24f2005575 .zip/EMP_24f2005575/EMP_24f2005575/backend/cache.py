#24f2005575- Asmita
#24f2005575- Asmita
import json
import time
import redis
from config import Config

_client = None
_down_until = 0


def _redis():
    global _client, _down_until
    if time.time() < _down_until:
        return None
    if _client is None:
        try:
            c = redis.Redis.from_url(Config.REDIS_URL, socket_connect_timeout=1,
                                     socket_timeout=1, decode_responses=True)
            c.ping()
            _client = c
        except Exception:
            _down_until = time.time() + 30
            return None
    return _client


def cached(key, fn, ttl=None):
    r = _redis()
    ttl = ttl or Config.CACHE_DEFAULT_TTL
    if r:
        try:
            hit = r.get(key)
            if hit is not None:
                return json.loads(hit)
        except Exception:
            pass
    value = fn()
    if r:
        try:
            r.setex(key, ttl, json.dumps(value))
        except Exception:
            pass
    return value


def invalidate(*prefixes):
    r = _redis()
    if not r:
        return
    try:
        for p in prefixes:
            for k in r.scan_iter(p + "*"):
                r.delete(k)
    except Exception:
        pass
