#24f2005575- Asmita
#24f2005575- Asmita
import os
from flask import Flask, jsonify, send_from_directory, render_template
from werkzeug.security import generate_password_hash
from config import Config
from models import db, User

FRONTEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")


def create_app():
    app = Flask(__name__, static_folder=os.path.join(FRONTEND_DIR, "static"),
                static_url_path="/static", template_folder=FRONTEND_DIR)
    app.config.from_object(Config)
    db.init_app(app)

    from auth import auth_bp
    from routes_admin import admin_bp
    from routes_examiner import examiner_bp
    from routes_student import student_bp
    for bp in (auth_bp, admin_bp, examiner_bp, student_bp):
        app.register_blueprint(bp)

    with app.app_context():
        db.create_all()
        create_admin()

    @app.errorhandler(404)
    def not_found(e):
        return jsonify(error="Not found"), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify(error="Something went wrong on the server"), 500

    @app.get("/")
    def index():
        return render_template("index.html")

    return app


def create_admin():
    if not User.query.filter_by(role="admin").first():
        db.session.add(User(name="Administrator", email=Config.ADMIN_EMAIL, role="admin",
                            password_hash=generate_password_hash(Config.ADMIN_PASSWORD)))
        db.session.commit()
        print(f"[setup] Admin created: {Config.ADMIN_EMAIL} / {Config.ADMIN_PASSWORD}")


if __name__ == "__main__":
    create_app().run(debug=True, port=5000)
