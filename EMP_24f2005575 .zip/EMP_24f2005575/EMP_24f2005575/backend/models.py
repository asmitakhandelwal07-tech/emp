#24f2005575- Asmita
#24f2005575- Asmita
from datetime import datetime, date
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

exam_examiners = db.Table(
    "exam_examiners",
    db.Column("exam_id", db.Integer, db.ForeignKey("exam.id"), primary_key=True),
    db.Column("examiner_id", db.Integer, db.ForeignKey("user.id"), primary_key=True),
)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    phone = db.Column(db.String(20))
    roll_no = db.Column(db.String(30))
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    profile = db.relationship("ExaminerProfile", backref="user", uselist=False)

    def to_dict(self):
        d = {"id": self.id, "name": self.name, "email": self.email, "role": self.role,
             "phone": self.phone, "roll_no": self.roll_no, "active": self.active}
        if self.profile:
            d["department"] = self.profile.department
            d["status"] = self.profile.status
        return d


class ExaminerProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), unique=True)
    department = db.Column(db.String(100))
    contact = db.Column(db.String(50))
    status = db.Column(db.String(20), default="Active")


class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(20), default="Active")
    exams = db.relationship("Exam", backref="course", cascade="all, delete-orphan")

    def to_dict(self):
        return {"id": self.id, "code": self.code, "name": self.name,
                "description": self.description, "status": self.status,
                "exam_count": len(self.exams)}


class Exam(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey("course.id"), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    exam_type = db.Column(db.String(30), default="Viva")
    duration = db.Column(db.Integer, default=30)
    max_marks = db.Column(db.Integer, default=100)
    instructions = db.Column(db.Text)
    slot_create_start = db.Column(db.Date)
    slot_create_end = db.Column(db.Date)
    booking_start = db.Column(db.Date)
    booking_end = db.Column(db.Date)
    status = db.Column(db.String(20), default="Draft")
    results_published = db.Column(db.Boolean, default=False)

    rubrics = db.relationship("Rubric", backref="exam", cascade="all, delete-orphan")
    slots = db.relationship("Slot", backref="exam", cascade="all, delete-orphan")
    examiners = db.relationship("User", secondary=exam_examiners, backref="assigned_exams")

    def to_dict(self):
        iso = lambda d: d.isoformat() if d else None
        return {"id": self.id, "course_id": self.course_id,
                "course": self.course.name if self.course else None,
                "course_code": self.course.code if self.course else None,
                "name": self.name, "exam_type": self.exam_type, "duration": self.duration,
                "max_marks": self.max_marks, "instructions": self.instructions,
                "slot_create_start": iso(self.slot_create_start),
                "slot_create_end": iso(self.slot_create_end),
                "booking_start": iso(self.booking_start),
                "booking_end": iso(self.booking_end),
                "status": self.status, "results_published": self.results_published,
                "examiners": [{"id": u.id, "name": u.name} for u in self.examiners]}


class Rubric(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exam.id"), nullable=False)
    criterion = db.Column(db.String(150), nullable=False)
    max_marks = db.Column(db.Integer, nullable=False)
    weightage = db.Column(db.Float, default=0)
    description = db.Column(db.Text)

    def to_dict(self):
        return {"id": self.id, "exam_id": self.exam_id, "criterion": self.criterion,
                "max_marks": self.max_marks, "weightage": self.weightage,
                "description": self.description}


class Slot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey("exam.id"), nullable=False)
    examiner_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    capacity = db.Column(db.Integer, default=1)
    meeting_link = db.Column(db.String(300))
    status = db.Column(db.String(20), default="Available")

    examiner = db.relationship("User", foreign_keys=[examiner_id])
    bookings = db.relationship("Booking", backref="slot")

    @property
    def booked_count(self):
        return Booking.query.filter(Booking.slot_id == self.id,
                                    Booking.status != "Cancelled").count()

    @property
    def available_seats(self):
        return max(self.capacity - self.booked_count, 0)

    def refresh_status(self):
        if self.status in ("Cancelled", "Completed"):
            return
        self.status = "Full" if self.booked_count >= self.capacity else "Available"

    def to_dict(self):
        return {"id": self.id, "exam_id": self.exam_id, "exam": self.exam.name,
                "examiner_id": self.examiner_id, "examiner": self.examiner.name,
                "date": self.date.isoformat(),
                "start_time": self.start_time.strftime("%H:%M"),
                "end_time": self.end_time.strftime("%H:%M"),
                "capacity": self.capacity, "booked": self.booked_count,
                "available_seats": self.available_seats,
                "meeting_link": self.meeting_link, "status": self.status}


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    slot_id = db.Column(db.Integer, db.ForeignKey("slot.id"), nullable=False)
    exam_id = db.Column(db.Integer, db.ForeignKey("exam.id"), nullable=False)
    booking_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="Booked")

    student = db.relationship("User", foreign_keys=[student_id])
    exam = db.relationship("Exam")
    evaluation = db.relationship("Evaluation", backref="booking", uselist=False)

    def to_dict(self, show_result=True):
        d = {"id": self.id, "student_id": self.student_id, "student": self.student.name,
             "roll_no": self.student.roll_no, "slot_id": self.slot_id, "exam_id": self.exam_id,
             "exam": self.exam.name, "course": self.exam.course.name,
             "date": self.slot.date.isoformat(),
             "start_time": self.slot.start_time.strftime("%H:%M"),
             "end_time": self.slot.end_time.strftime("%H:%M"),
             "examiner": self.slot.examiner.name, "meeting_link": self.slot.meeting_link,
             "booking_date": self.booking_date.strftime("%Y-%m-%d %H:%M"),
             "status": self.status, "evaluated": self.evaluation is not None,
             "max_marks": self.exam.max_marks}
        if show_result and self.evaluation:
            d["marks"] = self.evaluation.total_marks
            d["remarks"] = self.evaluation.remarks
        return d


class Evaluation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey("booking.id"), unique=True)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    examiner_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    total_marks = db.Column(db.Float, default=0)
    remarks = db.Column(db.Text)
    evaluation_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="Evaluated")
    scores = db.relationship("EvaluationScore", backref="evaluation",
                             cascade="all, delete-orphan")


class EvaluationScore(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    evaluation_id = db.Column(db.Integer, db.ForeignKey("evaluation.id"))
    rubric_id = db.Column(db.Integer, db.ForeignKey("rubric.id"))
    marks = db.Column(db.Float, default=0)
    rubric = db.relationship("Rubric")


class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    message = db.Column(db.String(300))
    link = db.Column(db.String(300))
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {"id": self.id, "message": self.message, "link": self.link,
                "is_read": self.is_read,
                "created_at": self.created_at.strftime("%Y-%m-%d %H:%M")}


def notify(user_id, message, link=None):
    db.session.add(Notification(user_id=user_id, message=message, link=link))
